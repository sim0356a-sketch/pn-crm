<?php
$current = 'admins';
$page_title = 'Администраторы';
include __DIR__ . '/header.php';

// Проверяем права
if ($_SESSION['role'] !== 'superadmin') {
    echo "<div class='card alert'>Доступ запрещён. Только superadmin может управлять администраторами.</div>";
    include __DIR__ . '/footer.php'; exit;
}

$msg = '';

// Добавление
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='add') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role     = trim($_POST['role'] ?? 'admin');

    if ($username && $password) {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash, role) VALUES (?, ?, ?)");
        try {
            $stmt->execute([$username, $hash, $role]);
            $msg = "Администратор $username добавлен";
        } catch (PDOException $e) {
            $msg = "Ошибка: " . $e->getMessage();
        }
    } else {
        $msg = "Введите логин и пароль";
    }
}

// Удаление
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='delete') {
    $id = (int)$_POST['id'];
    if ($id !== (int)$_SESSION['admin_id']) { // нельзя удалить самого себя
        $pdo->prepare("DELETE FROM admins WHERE id=?")->execute([$id]);
        $msg = "Администратор #$id удалён";
    } else {
        $msg = "Нельзя удалить самого себя";
    }
}

// Изменение роли
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='update_role') {
    $id = (int)$_POST['id'];
    $role = trim($_POST['role']);
    $pdo->prepare("UPDATE admins SET role=? WHERE id=?")->execute([$role, $id]);
    $msg = "Роль обновлена";
}

// Список
$rows = $pdo->query("SELECT id, username, role FROM admins ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

?>

<?php if($msg): ?><div class="card alert"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

<div class="card">
  <h2>Добавить администратора</h2>
  <form method="post" class="grid two">
    <input type="hidden" name="action" value="add">
    <div class="form-row">
      <label>Логин</label>
      <input class="input" type="text" name="username" required>
    </div>
    <div class="form-row">
      <label>Пароль</label>
      <input class="input" type="password" name="password" required>
    </div>
    <div class="form-row">
      <label>Роль</label>
      <select class="input" name="role">
        <option value="superadmin">superadmin</option>
        <option value="admin" selected>admin</option>
        <option value="moderator">moderator</option>
      </select>
    </div>
    <div>
      <button class="btn primary"><i class="fa-solid fa-user-plus"></i> Добавить</button>
    </div>
  </form>
</div>

<div class="card">
  <h2>Список администраторов</h2>
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Логин</th>
        <th>Роль</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($rows as $r): ?>
      <tr>
        <td><?= (int)$r['id'] ?></td>
        <td><?= htmlspecialchars($r['username']) ?></td>
        <td>
          <form method="post" style="display:inline">
            <input type="hidden" name="action" value="update_role">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <select name="role" onchange="this.form.submit()" class="input">
              <option value="superadmin" <?= $r['role']==='superadmin'?'selected':'' ?>>superadmin</option>
              <option value="admin" <?= $r['role']==='admin'?'selected':'' ?>>admin</option>
              <option value="moderator" <?= $r['role']==='moderator'?'selected':'' ?>>moderator</option>
            </select>
          </form>
        </td>
        <td>
          <?php if((int)$r['id'] !== (int)$_SESSION['admin_id']): ?>
          <form method="post" style="display:inline" onsubmit="return confirm('Удалить администратора <?= htmlspecialchars($r['username']) ?>?')">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <button class="btn"><i class="fa-regular fa-trash-can"></i> Удалить</button>
          </form>
          <?php else: ?>
            <span style="color:#888">Нельзя удалить себя</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__.'/footer.php'; ?>
