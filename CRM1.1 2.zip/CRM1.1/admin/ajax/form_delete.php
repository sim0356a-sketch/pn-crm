<?php
require_once __DIR__ . '/../../config.php';
header('Content-Type: application/json');

$id = (int)($_POST['id'] ?? 0);
if(!$id){ echo json_encode(['status'=>'error','message'=>'ID не указан']); exit; }

// получаем данные анкеты
$stmt = $pdo->prepare("SELECT hash FROM form_sessions WHERE id=? LIMIT 1");
$stmt->execute([$id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$row){ echo json_encode(['status'=>'error','message'=>'Анкета не найдена']); exit; }

$hash = $row['hash'];

// пути к папкам с файлами
$uploadDirs = [
  __DIR__ . "/../../uploads/representatives/$hash",
  __DIR__ . "/../../anketa/uploads/representatives/$hash"
];

foreach($uploadDirs as $dir){
  if(is_dir($dir)){
    $files = glob($dir.'/*');
    foreach($files as $f){ @unlink($f); }
    @rmdir($dir);
  }
}

// удаляем анкету из БД
$pdo->prepare("DELETE FROM form_sessions WHERE id=?")->execute([$id]);

echo json_encode(['status'=>'ok','message'=>"Анкета #$id удалена"]);
