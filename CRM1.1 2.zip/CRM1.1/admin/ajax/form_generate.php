<?php
require_once __DIR__ . '/../../config.php';
header('Content-Type: application/json');

$namesave        = $_POST['namesave'] ?? '';
$name_poluchatel = $_POST['name_poluchatel'] ?? '';
$phone           = $_POST['phone'] ?? '';
$order_id        = $_POST['order_id'] ?? '';
$hash = bin2hex(random_bytes(16));

try {
    $stmt = $pdo->prepare("INSERT INTO form_sessions 
        (hash, namesave, name_poluchatel, Phone, order_id, telegram_topic_id, created_at, is_completed) 
        VALUES (?, ?, ?, ?, ?, ?, NOW(), 0)");
    $stmt->execute([$hash, $namesave, $name_poluchatel, $phone, $order_id, null]);

    $link = BASE_URL . '/form.php?hash=' . $hash;

    echo json_encode(['status'=>'ok','link'=>$link,'hash'=>$hash]);
} catch(PDOException $e) {
    echo json_encode(['status'=>'error','message'=>$e->getMessage()]);
}
