<?php
require_once __DIR__ . '/../../config.php';

$q = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? '';

$where = [];
$params = [];

if($q !== ''){
  $where[] = "(namesave LIKE :q OR name_poluchatel LIKE :q OR Phone LIKE :q)";
  $params[':q'] = "%$q%";
}
if($status === 'done') $where[] = "is_completed=1";
if($status === 'new')  $where[] = "is_completed=0";

$sql = "SELECT id, hash, namesave, name_poluchatel, Phone, is_completed, photo_count, updated_at
        FROM form_sessions";
if($where) $sql .= " WHERE " . implode(" AND ", $where);
$sql .= " ORDER BY updated_at DESC LIMIT 50";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<table class="table">
  <thead>
    <tr>
      <th>ID</th>
      <th>Герой</th>
      <th>Заполнил</th>
      <th>Телефон</th>
      <th>Фото</th>
      <th>Статус</th>
      <th>Обновлено</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($rows as $r): 
      $link = BASE_URL . "/form.php?hash=" . $r['hash']; ?>
    <tr>
      <td>#<?= (int)$r['id'] ?></td>
      <td><?= htmlspecialchars($r['namesave'] ?? '-') ?></td>
      <td><?= htmlspecialchars($r['name_poluchatel'] ?? '-') ?></td>
      <td><?= htmlspecialchars($r['Phone'] ?? '-') ?></td>
      <td><?= (int)$r['photo_count'] ?></td>
      <td><?= $r['is_completed'] ? '<span class="badge">Готова</span>' : '<span class="badge">Новая</span>' ?></td>
      <td><?= htmlspecialchars($r['updated_at'] ?? '') ?></td>
      <td>
        <?php if(!empty($r['hash'])): ?>
          <a class="btn" href="<?= $link ?>" target="_blank"><i class="fa-regular fa-eye"></i> Открыть</a>
          <button class="btn" onclick="copyLink('<?= $link ?>')"><i class="fa-regular fa-copy"></i></button>
        <?php endif; ?>
        <button class="btn" onclick="deleteForm(<?= (int)$r['id'] ?>)"><i class="fa-regular fa-trash-can"></i> Удалить</button>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>