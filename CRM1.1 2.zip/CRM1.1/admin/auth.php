<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config.php'; // ожидается, что создаёт $pdo (PDO)
function require_admin() {
  if (empty($_SESSION['admin_id'])) {
    header('Location: /admin/login.php'); exit;
  }
}
function current_admin() {
  return [
    'id' => $_SESSION['admin_id'] ?? null,
    'username' => $_SESSION['username'] ?? null,
    'role' => $_SESSION['role'] ?? null
  ];
}
?>
