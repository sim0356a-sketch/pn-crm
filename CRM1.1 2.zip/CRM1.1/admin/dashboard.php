<?php
$current='dashboard'; $page_title='Обзор';
include __DIR__.'/header.php';

// Карточки: формы (всего/завершено), представители, заказы за сегодня
$today = date('Y-m-d');
$totalForms = (int)$pdo->query("SELECT COUNT(*) FROM form_sessions")->fetchColumn();
$doneForms  = (int)$pdo->query("SELECT COUNT(*) FROM form_sessions WHERE is_completed=1")->fetchColumn();
$repsCount  = (int)$pdo->query("SELECT COUNT(*) FROM representatives")->fetchColumn();
$adminsCount= (int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();

// Если есть daily_stats — берём последние
$daily = $pdo->query("SELECT * FROM daily_stats ORDER BY stat_date DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
?>
<div class="grid three">
  <div class="card">
    <h2><i class="fa-regular fa-rectangle-list"></i> Анкеты</h2>
    <p class="footer-note">Всего: <strong><?= $totalForms ?></strong></p>
    <p class="footer-note">Завершено: <strong><?= $doneForms ?></strong></p>
  </div>
  <div class="card">
    <h2><i class="fa-solid fa-user-tie"></i> Представители</h2>
    <p class="footer-note">Всего: <strong><?= $repsCount ?></strong></p>
  </div>
  <div class="card">
    <h2><i class="fa-solid fa-user-shield"></i> Администраторы</h2>
    <p class="footer-note">Всего: <strong><?= $adminsCount ?></strong></p>
  </div>
</div>

<div class="card">
  <h2>Суточная статистика</h2>
  <?php if($daily): ?>
    <div class="grid three">
      <div class="alert"><strong>Дата:</strong> <?= htmlspecialchars($daily['stat_date']) ?></div>
      <div class="alert"><strong>Создано форм:</strong> <?= (int)$daily['forms_created'] ?></div>
      <div class="alert"><strong>Завершено форм:</strong> <?= (int)$daily['forms_completed'] ?></div>
    </div>
  <?php else: ?>
    <p class="footer-note">Нет записей в daily_stats.</p>
  <?php endif; ?>
</div>

<div class="card">
  <h2>Последние действия админов</h2>
  <table class="table">
    <thead><tr><th>Время</th><th>Админ</th><th>Действие</th><th>Описание</th></tr></thead>
    <tbody>
      <?php
        $stmt = $pdo->query("SELECT l.created_at, a.login AS admin_login, l.action, l.details
                              FROM admin_logs l LEFT JOIN admins a ON a.id=l.admin_id
                              ORDER BY l.created_at DESC LIMIT 10");
        foreach($stmt as $row):
      ?>
        <tr>
          <td><?= htmlspecialchars($row['created_at']) ?></td>
          <td><?= htmlspecialchars($row['admin_login'] ?? '-') ?></td>
          <td><?= htmlspecialchars($row['action']) ?></td>
          <td><?= htmlspecialchars($row['details']) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__.'/footer.php'; ?>
