<?php
$current='forms'; 
$page_title='Формы (анкетные сессии)';
include __DIR__.'/header.php';

$msg = '';

?>

<?php if($msg): ?>
<div class="card alert">
  <?php if(strpos($msg, '/form.php?hash=') !== false): ?>
    Ссылка создана: <a href="<?= htmlspecialchars($msg) ?>" target="_blank"><?= htmlspecialchars($msg) ?></a>
    <button class="btn" onclick="copyLink('<?= htmlspecialchars($msg) ?>')">
      <i class="fa-regular fa-copy"></i> Копировать
    </button>
  <?php else: ?>
    <?= $msg ?>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- Генерация ссылки -->
<div class="card">
  <h2>Создать ссылку на анкету</h2>
  <form id="generate-form" class="grid two">
    <div class="form-row">
      <label>ФИО Героя</label>
      <input class="input" type="text" name="namesave">
    </div>
    <div class="form-row">
      <label>Кто заполняет</label>
      <input class="input" type="text" name="name_poluchatel">
    </div>
    <div class="form-row">
      <label>Телефон</label>
      <input class="input" type="text" name="phone">
    </div>
    <div class="form-row">
      <label>ID заказа</label>
      <input class="input" type="text" name="order_id">
    </div>
    <div>
      <button class="btn primary" type="submit"><i class="fa-solid fa-link"></i> Сгенерировать</button>
    </div>
  </form>
</div>


<!-- Фильтры -->
<div class="card">
  <h2>Фильтры</h2>
  <div class="grid two">
    <div class="form-row">
      <label>Поиск</label>
      <input class="input" type="text" name="q" placeholder="ФИО, телефон">
    </div>
    <div class="form-row">
      <label>Статус</label>
      <select class="input" name="status">
        <option value="">Все</option>
        <option value="new">Новые</option>
        <option value="done">Готовы</option>
      </select>
    </div>
  </div>
  <div style="margin-top:12px">
    <button class="btn primary" onclick="loadForms()"><i class="fa-solid fa-magnifying-glass"></i> Применить</button>
    <button class="btn" onclick="resetFilters()">Сброс</button>
  </div>
</div>

<!-- Список -->
<div class="card">
  <h2>Список анкет</h2>
  <div id="forms-container">Загрузка...</div>
</div>

<!-- Toast -->
<div id="toast-container"></div>
<style>
#toast-container { position:fixed; bottom:20px; right:20px; display:flex; flex-direction:column; gap:10px; z-index:9999; }
.toast { background:#fff; border:1px solid #d2d2d7; box-shadow:0 4px 12px rgba(0,0,0,0.15); border-radius:12px; padding:14px 18px; font-size:15px; color:#1d1d1f; animation:fadeIn .3s, fadeOut .3s 2.7s; }
.toast.success { border-left:6px solid #34c759; }
.toast.error { border-left:6px solid #ff3b30; }
@keyframes fadeIn { from{opacity:0; transform:translateY(20px);} to{opacity:1; transform:translateY(0);} }
@keyframes fadeOut{ from{opacity:1;} to{opacity:0;} }
</style>

<script>
function showToast(message, type='success') {
  const toast = document.createElement('div');
  toast.className = 'toast ' + type;
  toast.textContent = message;
  document.getElementById('toast-container').appendChild(toast);
  setTimeout(()=> toast.remove(), 3000);
}

function copyLink(text) {
  navigator.clipboard.writeText(text).then(() => {
    showToast('Ссылка скопирована', 'success');
  }).catch(() => {
    showToast('Ошибка копирования', 'error');
  });
}

function loadForms() {
  const q = document.querySelector('input[name="q"]').value;
  const status = document.querySelector('select[name="status"]').value;
  fetch('/admin/ajax/forms_list.php?q=' + encodeURIComponent(q) + '&status=' + status)
    .then(r => r.text())
    .then(html => {
      document.getElementById('forms-container').innerHTML = html;
    });
}

function deleteForm(id) {
  if(!confirm("Удалить анкету #" + id + " вместе с файлами?")) return;
  fetch('/admin/ajax/form_delete.php', {
    method: 'POST',
    headers: { 'Content-Type':'application/x-www-form-urlencoded' },
    body: 'id='+id
  })
  .then(r => r.json())
  .then(res => {
    if(res.status==='ok') showToast(res.message,'success');
    else showToast(res.message,'error');
    loadForms();
  });
}

function resetFilters(){
  document.querySelector('input[name="q"]').value='';
  document.querySelector('select[name="status"]').value='';
  loadForms();
}

document.getElementById('generate-form').addEventListener('submit', function(e){
  e.preventDefault();
  const formData = new FormData(this);
  fetch('/admin/ajax/form_generate.php', {
    method:'POST',
    body:formData
  })
  .then(r=>r.json())
  .then(res=>{
    if(res.status==='ok'){
      showToast('Ссылка создана и добавлена в список','success');
      loadForms(); // обновляем список анкет
    } else {
      showToast('Ошибка: '+res.message,'error');
    }
  })
  .catch(()=>showToast('Ошибка соединения','error'));
});

document.addEventListener('DOMContentLoaded', loadForms);
</script>
<?php include __DIR__.'/footer.php'; ?>