<?php
require_once __DIR__ . '/auth.php';
require_admin();
$current = $current ?? '';
$admin = current_admin();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($page_title ?? 'Админка') ?> | Память Народов</title>
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="stylesheet" href="<?= dirname($_SERVER['SCRIPT_NAME']) ?>/assets/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body>
<div class="layout">
  <aside class="sidebar" id="sidebar">
    <div class="brand"><i class="fa-solid fa-leaf"></i> Память Народов</div>
    <div class="search">
      <i class="fa-solid fa-magnifying-glass"></i>
      <input type="search" placeholder="Поиск по админке">
    </div>
    <nav class="nav">
      <a href="/admin/dashboard.php" class="<?= $current==='dashboard'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> Dashboard</a>
      <a href="/admin/forms.php" class="<?= $current==='forms'?'active':'' ?>"><i class="fa-regular fa-rectangle-list"></i> Формы</a>
      <a href="/admin/admins.php" class="<?= $current==='admins'?'active':'' ?>"><i class="fa-solid fa-user-shield"></i> Администраторы</a>
      <a href="/admin/representatives.php" class="<?= $current==='representatives'?'active':'' ?>"><i class="fa-solid fa-user-tie"></i> Представители</a>
      <a href="/admin/rewards.php" class="<?= $current==='rewards'?'active':'' ?>"><i class="fa-solid fa-medal"></i> Награды</a>
      <a href="/admin/settings.php" class="<?= $current==='settings'?'active':'' ?>"><i class="fa-solid fa-gear"></i> Настройки</a>
      <a href="/admin/logs.php" class="<?= $current==='logs'?'active':'' ?>"><i class="fa-regular fa-file-lines"></i> Логи</a>
      <a href="/admin/logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i> Выход</a>
    </nav>
  </aside>
  <main>
    <div class="topbar">
      <div class="title">
        <span class="burger" onclick="toggleSidebar()"><i class="fa-solid fa-bars"></i></span>
        <strong><?= htmlspecialchars($page_title ?? 'Админ-панель') ?></strong>
      </div>
      <div class="actions">
        <span class="footer-note" style="margin-right:10px">Вы вошли как <?= htmlspecialchars($admin['username']) ?> (<?= htmlspecialchars($admin['role']) ?>)</span>
        <a href="/" class="btn primary"><i class="fa-solid fa-house"></i> На сайт</a>
      </div>
    </div>
    <div class="content">

<script>
  function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
  }

  // Автоматическое закрытие сайдбара при клике на пункт меню (на мобилке)
  document.addEventListener("DOMContentLoaded", function() {
    const sidebar = document.getElementById('sidebar');
    const links = sidebar.querySelectorAll('a');
    links.forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth <= 768) {
          sidebar.classList.remove('active');
        }
      });
    });
  });
</script>