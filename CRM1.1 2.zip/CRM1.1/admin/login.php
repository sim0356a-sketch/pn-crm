<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/php_errors.log');
?>
<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config.php'; // $pdo
$error = '';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $username = trim($_POST['username'] ?? '');
  $pass  = $_POST['password'] ?? '';
  if($username && $pass){
    $stmt = $pdo->prepare("SELECT id, username, password_hash, role FROM admins WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if($row && password_verify($pass, $row['password_hash'])){
      $_SESSION['admin_id'] = (int)$row['id'];
      $_SESSION['username'] = $row['username'];
      $_SESSION['role']  = $row['role'];
      header('Location: /admin/dashboard.php'); exit;
    } else {
      $error = 'Неверный логин или пароль';
    }
  } else {
    $error = 'Введите логин и пароль';
  }
}
?><!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Вход в личный кабинет</title>
  <link rel="stylesheet" href="/admin/assets/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body style="display:flex;align-items:center;justify-content:center;min-height:100vh;background:#f5f5f7">
  <div class="card" style="width:100%;max-width:420px">
    <div class="brand" style="margin:0 0 10px 0">Память Народов</div>
    <h2 style="margin:0 0 6px 0">Вход</h2>
    <?php if(!empty($error)): ?><p style="color:#b00020;margin:8px 0 0 0"><?= htmlspecialchars($error) ?></p><?php endif; ?>
    <form method="post" style="margin-top:12px" autocomplete="off">
      <div class="form-row">
        <label>Логин</label>
        <input class="input" type="text" name="username" required placeholder="mail@yandex.ru">
      </div>
      <div class="form-row">
        <label>Пароль</label>
        <input class="input" type="password" name="password" required placeholder="••••••••">
      </div>
      <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:12px">
        <button class="btn" type="reset">Сброс</button>
        <button class="btn primary" type="submit"><i class="fa-solid fa-right-to-bracket"></i> Войти</button>
      </div>
    </form>
  </div>
</body>
</html>
