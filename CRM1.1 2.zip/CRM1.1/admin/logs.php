<?php
$current='logs';
$page_title='Логи админов';
include __DIR__.'/header.php';

// ===== Параметры фильтра =====
$admin_id  = isset($_GET['admin_id']) ? (int)$_GET['admin_id'] : 0;
$action    = trim($_GET['action'] ?? '');
$q         = trim($_GET['q'] ?? ''); // поиск по details
$date_from = trim($_GET['date_from'] ?? '');
$date_to   = trim($_GET['date_to'] ?? '');

$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = 30;
$offset  = ($page-1)*$perPage;

// ===== Для селектов =====
$admins = $pdo->query("SELECT id, username FROM admins ORDER BY username ASC")->fetchAll(PDO::FETCH_ASSOC);
$actions = $pdo->query("SELECT DISTINCT action FROM admin_logs ORDER BY action ASC")->fetchAll(PDO::FETCH_COLUMN);

// ===== WHERE-конструктор =====
$conds = [];
$params = [];

if ($admin_id > 0) {
  $conds[] = "l.admin_id = :admin_id";
  $params[':admin_id'] = $admin_id;
}
if ($action !== '') {
  $conds[] = "l.action = :action";
  $params[':action'] = $action;
}
if ($q !== '') {
  $conds[] = "l.details LIKE :q";
  $params[':q'] = "%$q%";
}
if ($date_from !== '') {
  // начало дня
  $conds[] = "l.created_at >= :date_from";
  $params[':date_from'] = $date_from . " 00:00:00";
}
if ($date_to !== '') {
  // конец дня
  $conds[] = "l.created_at <= :date_to";
  $params[':date_to'] = $date_to . " 23:59:59";
}

$where = $conds ? "WHERE ".implode(" AND ", $conds) : "";

// ===== Подсчёт и выборка =====
$sqlBase = "FROM admin_logs l LEFT JOIN admins a ON a.id = l.admin_id $where";

$stmt = $pdo->prepare("SELECT COUNT(*) $sqlBase");
$stmt->execute($params);
$totalRows = (int)$stmt->fetchColumn();

$sql = "SELECT l.id, l.created_at, l.action, l.description, l.ip_address, l.user_agent, l.admin_id, a.username
        $sqlBase
        ORDER BY l.created_at DESC
        LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($sql);
foreach ($params as $k=>$v) $stmt->bindValue($k, $v);
$stmt->bindValue(':limit',  $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset,  PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Параметры для ссылки экспорта
$qs_export = http_build_query([
  'admin_id'=>$admin_id, 'action'=>$action, 'q'=>$q,
  'date_from'=>$date_from, 'date_to'=>$date_to
]);
?>

<div class="card">
  <h2>Фильтры</h2>
  <form method="get" class="grid two">
    <div class="form-row">
      <label>Администратор</label>
      <select class="input" name="admin_id">
        <option value="0">Все</option>
        <?php foreach($admins as $a): ?>
          <option value="<?= (int)$a['id'] ?>" <?= $admin_id===(int)$a['id']?'selected':'' ?>>
            <?= htmlspecialchars($a['username']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-row">
      <label>Действие</label>
      <select class="input" name="action">
        <option value="">Все</option>
        <?php foreach($actions as $act): ?>
          <option value="<?= htmlspecialchars($act) ?>" <?= $action===$act?'selected':'' ?>>
            <?= htmlspecialchars($act) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-row">
      <label>Поиск по деталям</label>
      <input class="input" type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Текст в описании...">
    </div>

    <div class="form-row">
      <label>Диапазон дат</label>
      <div style="display:flex; gap:8px">
        <input class="input" type="date" name="date_from" value="<?= htmlspecialchars($date_from) ?>">
        <input class="input" type="date" name="date_to"   value="<?= htmlspecialchars($date_to) ?>">
      </div>
    </div>

    <div style="display:flex; align-items:flex-end; gap:10px">
      <button class="btn primary" type="submit"><i class="fa-solid fa-filter"></i> Применить</button>
      <a class="btn" href="/admin/logs.php"><i class="fa-solid fa-eraser"></i> Сброс</a>
      <a class="btn" href="/admin/logs_export.php?<?= $qs_export ?>"><i class="fa-solid fa-file-export"></i> Экспорт CSV</a>
    </div>
  </form>
</div>

<div class="card">
  <h2>Лента действий</h2>
  <table class="table">
    <thead>
      <tr>
        <th>Время</th>
        <th>Админ</th>
        <th>Действие</th>
        <th>Детали</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><?= htmlspecialchars($r['created_at']) ?></td>
          <td><?= htmlspecialchars($r['username'] ?? ('ID '.(int)$r['admin_id'])) ?></td>
          <td><span class="badge"><?= htmlspecialchars($r['action']) ?></span></td>
          <td><?= nl2br(htmlspecialchars($r['description'] ?? '')) ?><br>
          <small>IP: <?= htmlspecialchars($r['ip_address'] ?? '-') ?> | <?= htmlspecialchars($r['user_agent'] ?? '-') ?></small>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if(!$rows): ?>
        <tr><td colspan="4" style="color:#6e6e73">Ничего не найдено</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <?php
    $pages = max(1, (int)ceil($totalRows / $perPage));
    if ($pages > 1):
      // строим ссылки пагинации, сохраняя фильтры
      $base_qs = $_GET;
  ?>
  <div style="margin-top:12px">
    <?php for($p=1;$p<=$pages;$p++):
      $base_qs['page'] = $p;
      $qs = http_build_query($base_qs);
    ?>
      <a class="btn<?= $p==$page?' primary':'' ?>" href="?<?= $qs ?>"><?= $p ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<?php include __DIR__.'/footer.php'; ?>
