<?php
// Экспорт CSV по тем же фильтрам, что в logs.php
require_once __DIR__ . '/../config.php';

// Параметры фильтра
$admin_id  = isset($_GET['admin_id']) ? (int)$_GET['admin_id'] : 0;
$action    = trim($_GET['action'] ?? '');
$q         = trim($_GET['q'] ?? '');
$date_from = trim($_GET['date_from'] ?? '');
$date_to   = trim($_GET['date_to'] ?? '');

$conds = [];
$params = [];

if ($admin_id > 0) { $conds[] = "l.admin_id = :admin_id"; $params[':admin_id'] = $admin_id; }
if ($action !== '') { $conds[] = "l.action = :action"; $params[':action'] = $action; }
if ($q !== '') { $conds[] = "l.details LIKE :q"; $params[':q'] = "%$q%"; }
if ($date_from !== '') { $conds[] = "l.created_at >= :date_from"; $params[':date_from'] = $date_from.' 00:00:00'; }
if ($date_to !== '') { $conds[] = "l.created_at <= :date_to"; $params[':date_to'] = $date_to.' 23:59:59'; }

$where = $conds ? "WHERE ".implode(" AND ", $conds) : "";
$sql = "SELECT l.created_at, a.username AS admin, l.action, l.details
        FROM admin_logs l
        LEFT JOIN admins a ON a.id = l.admin_id
        $where
        ORDER BY l.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Заголовки для скачивания
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=admin_logs_'.date('Y-m-d_H-i-s').'.csv');

// Вывод CSV
$out = fopen('php://output', 'w');
// BOM для Excel (чтобы не съедал UTF-8)
fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
fputcsv($out, ['created_at','admin','action','details'], ';');

foreach ($rows as $r) {
  fputcsv($out, [
    $r['created_at'],
    $r['admin'],
    $r['action'],
    $r['details']
  ], ';');
}
fclose($out);
