<?php
$current = 'representatives'; 
$page_title = 'Редактировать представителя';
include __DIR__.'/header.php';

// Включаем отображение ошибок для отладки (можно отключить на боевом)
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/edit_rep_errors.log');

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM representatives WHERE id=? LIMIT 1");
$stmt->execute([$id]);
$rep = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$rep) {
  echo "<div class='card alert'>Представитель не найден</div>";
  include __DIR__.'/footer.php'; 
  exit;
}

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name   = trim($_POST['full_name']   ?? '');
  $city   = trim($_POST['city']        ?? '');
  $phone  = trim($_POST['phone']       ?? '');
  $orders = (int)($_POST['orders_count'] ?? 0);

  // Логируем входящие данные
  file_put_contents(
    __DIR__.'/edit_rep.log', 
    date('Y-m-d H:i:s') . " UPDATE DATA: " . json_encode([$name, $city, $phone, $orders, $id], JSON_UNESCAPED_UNICODE) . "\n", 
    FILE_APPEND
  );

  $stmt = $pdo->prepare("UPDATE representatives SET full_name=?, phone=?, orders_count=? WHERE id=?");
  $stmt->execute([$name, $phone, $orders, $id]);

  $msg = ($stmt->rowCount() > 0) 
      ? "Изменения сохранены" 
      : "Изменений не произошло (данные могли совпадать)";

  // Заново подтягиваем обновлённые данные из БД
  $stmt = $pdo->prepare("SELECT * FROM representatives WHERE id=? LIMIT 1");
  $stmt->execute([$id]);
  $rep = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<?php if($msg): ?>
  <div class="card alert"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="card">
  <h2>Редактирование представителя</h2>
  <form method="post" class="grid two">
    <div class="form-row">
      <label>ФИО</label>
      <input class="input" type="text" name="full_name" value="<?= htmlspecialchars($rep['full_name'] ?? '') ?>" required>
    </div>
    <div class="form-row">
      <label>Телефон</label>
      <input class="input" type="text" name="phone" value="<?= htmlspecialchars($rep['phone'] ?? '') ?>" required>
    </div>
    <div class="form-row">
      <label>Количество заказов</label>
      <input class="input" type="number" name="orders_count" value="<?= (int)($rep['orders_count'] ?? 0) ?>">
    </div>
    <div>
      <button type="submit" class="btn primary">
        <i class="fa-solid fa-floppy-disk"></i> Сохранить
      </button>
      <a class="btn" href="representatives.php">
        <i class="fa-solid fa-arrow-left"></i> Назад
      </a>
    </div>
  </form>
</div>

<?php include __DIR__.'/footer.php'; ?>
