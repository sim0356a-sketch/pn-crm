<?php
$current='representatives'; 
$page_title='Представители';
include __DIR__.'/header.php';

$msg = '';

// Добавление нового представителя
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='add'){
  $name = trim($_POST['full_name'] ?? '');
  $phone = trim($_POST['phone'] ?? '');
  $promo = trim($_POST['promo_code'] ?? '');
  if($name && $phone && $promo){
    $stmt = $pdo->prepare("INSERT INTO representatives (full_name, phone, promo_code, orders_count, total_orders, is_active, created_at) VALUES (?, ?, ?, 0, 0, 1, NOW())");
    $stmt->execute([$name, $phone, $promo]);
    $msg = "Представитель «$name» добавлен";
  } else {
    $msg = "Укажите ФИО, телефон и промокод";
  }
}

// Удаление представителя
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='delete'){
  $id = (int)$_POST['id'];
  // Удаляем его награды
  $pdo->prepare("DELETE FROM representative_rewards WHERE representative_id=?")->execute([$id]);
  // Удаляем представителя
  $pdo->prepare("DELETE FROM representatives WHERE id=?")->execute([$id]);
  $msg = "Представитель #$id удалён";
}

// Поиск
$search = trim($_GET['q'] ?? '');
$where = $search ? "WHERE (full_name LIKE :q OR phone LIKE :q OR promo_code LIKE :q)" : "";
$params = $search ? [':q'=>"%$search%"] : [];

$stmt = $pdo->prepare("SELECT id, full_name, phone, promo_code, orders_count, total_orders, is_active, created_at, updated_at FROM representatives $where ORDER BY id DESC LIMIT 200");
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php if($msg): ?><div class="card alert"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

<div class="card">
  <h2>Добавить представителя</h2>
  <form method="post" class="grid two">
    <input type="hidden" name="action" value="add">
    <div class="form-row">
      <label>ФИО</label>
      <input class="input" type="text" name="full_name" required>
    </div>
    <div class="form-row">
      <label>Телефон</label>
      <input class="input" type="text" name="phone" required>
    </div>
    <div class="form-row">
      <label>Промокод</label>
      <input class="input" type="text" name="promo_code" required>
    </div>
    <div>
      <button class="btn primary"><i class="fa-solid fa-user-plus"></i> Добавить</button>
    </div>
  </form>
</div>

<div class="card">
  <h2>Фильтр</h2>
  <form method="get" class="grid two">
    <div class="form-row">
      <label>Поиск</label>
      <input class="input" type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="ФИО, телефон, промокод">
    </div>
    <div style="display:flex;align-items:flex-end;gap:10px">
      <button class="btn primary"><i class="fa-solid fa-magnifying-glass"></i> Найти</button>
      <a class="btn" href="/admin/representatives.php">Сброс</a>
    </div>
  </form>
</div>

<div class="card">
  <h2>Список представителей</h2>
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>ФИО</th>
        <th>Телефон</th>
        <th>Промокод</th>
        <th>Заказы</th>
        <th>Всего заказов</th>
        <th>Активен</th>
        <th>Добавлен</th>
        <th>Обновлён</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($rows as $r): ?>
      <tr>
        <td><?= (int)$r['id'] ?></td>
        <td><?= htmlspecialchars($r['full_name'] ?? '-') ?></td>
        <td><?= htmlspecialchars($r['phone'] ?? '-') ?></td>
        <td><?= htmlspecialchars($r['promo_code'] ?? '-') ?></td>
        <td><span class="badge"><?= (int)$r['orders_count'] ?></span></td>
        <td><span class="badge"><?= (int)$r['total_orders'] ?></span></td>
        <td><?= $r['is_active'] ? '✅' : '❌' ?></td>
        <td><?= htmlspecialchars($r['created_at'] ?? '') ?></td>
        <td><?= htmlspecialchars($r['updated_at'] ?? '') ?></td>
        <td>
          <a class="btn" href="representative_edit.php?id=<?= (int)$r['id'] ?>"><i class="fa-regular fa-pen-to-square"></i> Редакт.</a>
          <form method="post" style="display:inline" onsubmit="return confirm('Удалить представителя #<?= (int)$r['id'] ?>?')">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <button class="btn"><i class="fa-regular fa-trash-can"></i> Удалить</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__.'/footer.php'; ?>
