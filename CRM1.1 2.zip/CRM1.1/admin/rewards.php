<?php
$current = 'rewards';
$page_title = 'Награды представителей';
include __DIR__ . '/header.php';

/* ВКЛ/ВЫКЛ отладку через ?debug=1 */
$DEBUG = isset($_GET['debug']);
if ($DEBUG) { error_reporting(E_ALL); ini_set('display_errors', 1); }

/* ===== Helpers ===== */
function table_exists(PDO $pdo, string $name): bool {
  $st = $pdo->prepare("SHOW TABLES LIKE ?");
  $st->execute([$name]);
  return (bool)$st->fetchColumn();
}
function column_exists(PDO $pdo, string $table, string $col): bool {
  $st = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
  $st->execute([$col]);
  return (bool)$st->fetch(PDO::FETCH_ASSOC);
}
function find_table(PDO $pdo, array $candidates): ?string {
  foreach ($candidates as $t) if (table_exists($pdo, $t)) return $t;
  return null;
}

/* ===== Определяем реальные имена таблиц ===== */
$rewardsTable = find_table($pdo, ['representative_rewards','rewards','rep_rewards']);
$repsTable    = find_table($pdo, ['representatives','representative','reps']);

if (!$rewardsTable || !$repsTable) {
  echo "<div class='card alert'><b>Ошибка конфигурации БД.</b><br>
        Не найдены обязательные таблицы.<br>
        rewards: <code>".htmlspecialchars($rewardsTable ?: '—')."</code>,
        reps: <code>".htmlspecialchars($repsTable ?: '—')."</code>.<br>
        Проверьте названия таблиц.</div>";
  include __DIR__ . '/footer.php'; exit;
}

/* Есть ли колонка details у наград и full_name у представителей? */
$hasRewardDetails = column_exists($pdo, $rewardsTable, 'details');
$hasRepName       = column_exists($pdo, $repsTable, 'full_name');

/* ===== Обработка действий ===== */
$msg = '';
try {
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
      $rep_id = (int)($_POST['representative_id'] ?? 0);
      $type   = trim($_POST['reward_type'] ?? '');
      $details= trim($_POST['details'] ?? '');
      if ($rep_id && $type) {
        $sql = "INSERT INTO `$rewardsTable` (representative_id, reward_type"
             . ($hasRewardDetails ? ", details" : "")
             . ", created_at) VALUES (?, ?"
             . ($hasRewardDetails ? ", ?" : "")
             . ", NOW())";
        $st = $pdo->prepare($sql);
        $args = $hasRewardDetails ? [$rep_id, $type, $details] : [$rep_id, $type];
        $st->execute($args);
        $msg = "Награда добавлена";
      } else {
        $msg = "Выберите представителя и тип награды";
      }
    } elseif ($action === 'delete') {
      $id = (int)($_POST['id'] ?? 0);
      if ($id > 0) {
        $pdo->prepare("DELETE FROM `$rewardsTable` WHERE id=?")->execute([$id]);
        $msg = "Награда #$id удалена";
      }
    }
  }
} catch (Throwable $e) {
  $msg = "Ошибка: " . $e->getMessage();
  if ($DEBUG) {
    echo "<div class='card alert'><pre>".htmlspecialchars($e)."</pre></div>";
  }
}

/* ===== Данные для формы добавления ===== */
try {
  // Берём id + имя (если есть) или подставляем id как имя
  if ($hasRepName) {
    $reps = $pdo->query("SELECT id, full_name FROM `$repsTable` ORDER BY full_name ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
  } else {
    $reps = $pdo->query("SELECT id FROM `$repsTable` ORDER BY id ASC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($reps as &$r) { $r['full_name'] = 'ID '.$r['id']; }
  }
} catch (Throwable $e) {
  $reps = [];
  $msg = $msg ?: "Ошибка загрузки списка представителей";
  if ($DEBUG) echo "<div class='card alert'><pre>".htmlspecialchars($e)."</pre></div>";
}

/* ===== Фильтр ===== */
$type = $_GET['type'] ?? '';
$params = [];
$where  = '';
if ($type !== '') {
  $where = "WHERE r.reward_type = :t";
  $params[':t'] = $type;
}

/* ===== Список наград ===== */
$rows = [];
try {
  if ($hasRepName) {
    $sql = "SELECT r.id, r.representative_id, r.reward_type, "
         . ($hasRewardDetails ? "r.details, " : "")
         . "r.created_at, rep.full_name
           FROM `$rewardsTable` r
           LEFT JOIN `$repsTable` rep ON rep.id = r.representative_id
           $where
           ORDER BY r.id DESC
           LIMIT 200";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
  } else {
    // Без имени — возьмём имена отдельным запросом
    $sql = "SELECT r.id, r.representative_id, r.reward_type, "
         . ($hasRewardDetails ? "r.details, " : "")
         . "r.created_at
           FROM `$rewardsTable` r
           $where
           ORDER BY r.id DESC
           LIMIT 200";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Подтянем "имена"
    $ids = array_values(array_unique(array_column($rows, 'representative_id')));
    $nameMap = [];
    if ($ids) {
      $in = implode(',', array_fill(0, count($ids), '?'));
      $sqlMap = $hasRepName
        ? "SELECT id, full_name FROM `$repsTable` WHERE id IN ($in)"
        : "SELECT id FROM `$repsTable` WHERE id IN ($in)";
      $st = $pdo->prepare($sqlMap);
      $st->execute($ids);
      foreach ($st as $r) {
        $nameMap[$r['id']] = $hasRepName ? $r['full_name'] : ('ID '.$r['id']);
      }
    }
    // добавим rep_name в строки
    foreach ($rows as &$r) {
      $rid = (int)$r['representative_id'];
      $r['full_name'] = $nameMap[$rid] ?? ('ID '.$rid);
    }
  }
} catch (Throwable $e) {
  $rows = [];
  $msg = $msg ?: "Ошибка загрузки наград";
  if ($DEBUG) echo "<div class='card alert'><pre>".htmlspecialchars($e)."</pre></div>";
}

/* ===== UI ===== */
if ($msg) echo "<div class='card alert'>".htmlspecialchars($msg)."</div>";
?>

<div class="card">
  <h2>Добавить награду</h2>
  <form method="post" class="grid two">
    <input type="hidden" name="action" value="add">
    <div class="form-row">
      <label>Представитель</label>
      <select class="input" name="representative_id" required>
        <option value="">— выбрать —</option>
        <?php foreach ($reps as $rep): ?>
          <option value="<?= (int)$rep['id'] ?>">
            <?= htmlspecialchars($rep['full_name'] ?? ('ID '.$rep['id'])) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-row">
      <label>Тип награды</label>
      <select class="input" name="reward_type" required>
        <option value="badge">Значок</option>
        <option value="notebook">Блокнот</option>
        <option value="tshirt">Футболка</option>
      </select>
    </div>
    <div class="form-row" style="grid-column:1/-1">
      <label>Детали</label>
      <textarea class="input" name="details" rows="3" placeholder="Комментарий..."></textarea>
      <?php if(!$hasRewardDetails): ?>
        <p class="footer-note">Поле <code>details</code> отсутствует в таблице «<?= htmlspecialchars($rewardsTable) ?>». Комментарий не будет сохранён.</p>
      <?php endif; ?>
    </div>
    <div>
      <button class="btn primary"><i class="fa-solid fa-medal"></i> Добавить</button>
    </div>
  </form>
</div>

<div class="card">
  <h2>Фильтр наград</h2>
  <form method="get" class="grid two">
    <div class="form-row">
      <label>Тип</label>
      <select class="input" name="type">
        <option value="">Все</option>
        <option value="badge"   <?= $type==='badge'?'selected':'' ?>>Значок</option>
        <option value="notebook"<?= $type==='notebook'?'selected':'' ?>>Блокнот</option>
        <option value="tshirt"  <?= $type==='tshirt'?'selected':'' ?>>Футболка</option>
      </select>
    </div>
    <div style="display:flex;align-items:flex-end;gap:10px">
      <button class="btn primary"><i class="fa-solid fa-filter"></i> Фильтровать</button>
      <a class="btn" href="/admin/rewards.php">Сброс</a>
    </div>
  </form>
</div>

<div class="card">
  <h2>Список наград</h2>
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Представитель</th>
        <th>Тип</th>
        <?php if($hasRewardDetails): ?><th>Детали</th><?php endif; ?>
        <th>Дата</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td><?= htmlspecialchars($r['full_name'] ?? ('ID '.(int)$r['representative_id'])) ?></td>
          <td><span class="badge"><?= htmlspecialchars($r['reward_type']) ?></span></td>
          <?php if($hasRewardDetails): ?>
            <td><?= htmlspecialchars($r['details'] ?? '') ?></td>
          <?php endif; ?>
          <td><?= htmlspecialchars($r['created_at']) ?></td>
          <td>
            <form method="post" style="display:inline" onsubmit="return confirm('Удалить награду #<?= (int)$r['id'] ?>?')">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="btn"><i class="fa-regular fa-trash-can"></i> Удалить</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?>
        <tr><td colspan="<?= $hasRewardDetails?5:4 ?>" style="color:#6e6e73">Пока нет записей</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/footer.php'; ?>
