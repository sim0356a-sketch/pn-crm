<?php
$current='settings'; $page_title='Настройки';
include __DIR__.'/header.php';

// Пример чтения SMTP из config.php, если там есть $SMTP_HOST и т.п.
$SMTP_HOST = $SMTP_HOST ?? '';
$NOTIFY_EMAIL = $NOTIFY_EMAIL ?? '';
?>
<div class="grid two">
  <div class="card">
    <h2><i class="fa-solid fa-wand-magic-sparkles"></i> Общие</h2>
    <div class="form-row">
      <label>Email для уведомлений</label>
      <input class="input" type="email" value="<?= htmlspecialchars($NOTIFY_EMAIL) ?>" placeholder="info@example.com" disabled>
      <p class="footer-note">Настраивается в config.php (переменная $NOTIFY_EMAIL).</p>
    </div>
  </div>
  <div class="card">
    <h2><i class="fa-solid fa-plug"></i> Интеграции</h2>
    <div class="form-row">
      <label>SMTP Host</label>
      <input class="input" type="text" value="<?= htmlspecialchars($SMTP_HOST) ?>" placeholder="smtp.example.com" disabled>
      <p class="footer-note">Настраивается в config.php.</p>
    </div>
  </div>
</div>
<?php include __DIR__.'/footer.php'; ?>
