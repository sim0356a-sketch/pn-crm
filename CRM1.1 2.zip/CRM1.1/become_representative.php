<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <title>Стать участником — Память Народов</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root {--accent:#2687c0;--text:#1d1d1f;--muted:#6e6e73;}
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
         background:#fff;color:var(--text);line-height:1.4}
    header{position:fixed;top:20px;left:50%;transform:translateX(-50%);z-index:1000}
    .menu-island{display:flex;gap:24px;padding:10px 24px;background:rgba(0,0,0,.85);
                 backdrop-filter:blur(12px);border-radius:50px;box-shadow:0 6px 20px rgba(0,0,0,.25)}
    nav{display:flex;gap:20px}
    nav a{color:#fff;text-decoration:none;font-weight:500;font-size:clamp(12px,2vw,15px);
          padding:6px 12px;border-radius:12px;transition:.3s}
    nav a:hover{color:var(--accent)}

    section{min-height:100vh;display:flex;flex-direction:column;justify-content:center;align-items:center;
            padding:120px 20px;text-align:center;max-width:1200px;margin:0 auto}
    h1{font-size:clamp(32px,6vw,72px);font-weight:700;margin-bottom:20px}
    p{font-size:clamp(16px,2vw,20px);color:var(--muted)}
    form{display:flex;flex-direction:column;gap:16px;max-width:400px;width:100%;margin:40px auto}
    input{padding:14px 16px;font-size:16px;border:1px solid #ccc;border-radius:12px}
    button{padding:14px;font-size:16px;font-weight:600;background:var(--accent);color:#fff;
           border:none;border-radius:12px;cursor:pointer;transition:.3s}
    button:hover{background:#1b6ea3}
  </style>
</head>
<body>

<header>
  <div class="menu-island">
    <nav>
      <a href="/index.php">Главная</a>
      <a href="/representatives_rating.php">Рейтинг</a>
      <a href="/become_representative.php">Стать участником</a>
    </nav>
  </div>
</header>

<section>
  <h1>Стать участником</h1>
  <p>Заполни форму, и мы отправим Ваш промокод и передадим заявку менеджерам на консультацию.</p>
  <form method="post" action="save_representative.php" enctype="multipart/form-data">
    <input type="text" name="full_name" placeholder="Ваше имя" required>
    <input type="tel" name="phone" placeholder="Телефон" required>
    <input type="email" name="email" placeholder="Email" required>
    <button type="submit">Отправить заявку</button>
  </form>
</section>

</body>
</html>