<?php
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/config.php';

$hash = $_POST['hash'] ?? '';
$name = basename($_POST['name'] ?? '');
if (!$hash || !$name) { echo json_encode(['status'=>'error','message'=>'bad params']); exit; }

$base = __DIR__ . "/uploads/$hash";
$orig = $base . "/original/$name";
$thmb = $base . "/thumbs/$name";

$ok = true;
if (is_file($orig)) $ok = @unlink($orig) && $ok;
if (is_file($thmb)) $ok = @unlink($thmb) && $ok;

echo json_encode($ok ? ['status'=>'ok','message'=>'Фото удалено'] : ['status'=>'error','message'=>'Не удалось удалить файл']);
