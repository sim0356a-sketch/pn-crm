<?php

include __DIR__.'/config.php';

$hash = $_GET['hash'] ?? $_POST['hash'] ?? null;
if (!$hash) { header("Location: /index.php"); exit; }

$stmt=$pdo->prepare("SELECT * FROM form_sessions WHERE hash=? LIMIT 1");
$stmt->execute([$hash]);
$session=$stmt->fetch(PDO::FETCH_ASSOC);

if(!$session) die("Неверная ссылка.");
if(!empty($session['is_completed'])) { header("Location: /thanks.php?hash=".$hash); exit; }

// === Завершение анкеты ===
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['complete']) && $_POST['complete']=='1') {
    try {
        // 1) Актуализируем сессию
        $stmt=$pdo->prepare("SELECT * FROM form_sessions WHERE hash=? LIMIT 1");
        $stmt->execute([$hash]);
        $session=$stmt->fetch(PDO::FETCH_ASSOC);
        if(!$session){ throw new RuntimeException("Сессия не найдена для hash: ".$hash); }

        // 2) Создаём топик при отсутствии
        $topicId = $session['telegram_topic_id'] ?? null;
        if (empty($topicId)) {
            $heroName = $_POST['namesave'] ?? $session['namesave'] ?? 'Анкета';
            $topicId = createTelegramTopic($heroName);
            if ($topicId) {
                $upd = $pdo->prepare("UPDATE form_sessions SET telegram_topic_id=?, updated_at=NOW() WHERE hash=?");
                $upd->execute([$topicId, $hash]);
                error_log("✅ Создан топик Telegram #{$topicId} для hash {$hash}");
            } else {
                error_log("❌ Не удалось создать топик Telegram для hash {$hash}");
                @sendManagerTelegramMessage("❌ Не удалось создать топик Telegram\nГерой: ".($session['namesave']??'—')."\nЗаполнил: ".($session['name_poluchatel']??'—'));
            }
        }

        // 3) Резервная копия txt
        try {
            saveBackupTextFile($hash, $session);
        } catch (Throwable $e) {
            error_log("⚠️ Ошибка saveBackupTextFile: ".$e->getMessage());
        }

        // 4) Отправляем всё в Telegram (требует topic_id)
        try {
            sendAllDataToTelegram($hash);
        } catch (Throwable $e) {
            error_log("Ошибка отправки в Telegram: ".$e->getMessage());
        }

        // 5) Помечаем завершение
        $pdo->prepare("UPDATE form_sessions SET is_completed=1, updated_at=NOW() WHERE hash=?")->execute([$hash]);

        header("Location: /thanks.php?hash=".$hash);
        exit;
    } catch (Throwable $e) {
        error_log("FATAL complete-handler: ".$e->getMessage());
        http_response_code(500);
        echo "Произошла ошибка при завершении анкеты. Попробуйте ещё раз или свяжитесь с поддержкой.";
        exit;
    }
}


/* === AJAX загрузка фото === */
function getExtFromMime($mime) {
  switch($mime){
    case 'image/jpeg': return 'jpg';
    case 'image/png': return 'png';
    case 'image/webp': return 'webp';
    default: return 'bin';
  }
}
function makeThumb($src, $dst, $maxW=400, $maxH=400){
  [$w,$h,$t] = @getimagesize($src);
  if(!$w||!$h) return false;
  $r = min($maxW/$w,$maxH/$h);
  $nw=(int)($w*$r); $nh=(int)($h*$r);
  $thumb=imagecreatetruecolor($nw,$nh);
  switch($t){
    case IMAGETYPE_JPEG: $im=imagecreatefromjpeg($src); break;
    case IMAGETYPE_PNG:  $im=imagecreatefrompng($src); break;
    case IMAGETYPE_WEBP: $im=imagecreatefromwebp($src); break;
    default: return false;
  }
  imagecopyresampled($thumb,$im,0,0,0,0,$nw,$nh,$w,$h);
  switch($t){
    case IMAGETYPE_JPEG: imagejpeg($thumb,$dst,80); break;
    case IMAGETYPE_PNG:  imagepng($thumb,$dst,7); break;
    case IMAGETYPE_WEBP: imagewebp($thumb,$dst,80); break;
  }
  imagedestroy($thumb); imagedestroy($im);
  return true;
}

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_GET['upload']) && isset($_FILES['photos'])) {
  $base = __DIR__."/uploads/$hash";
  $orig = "$base/original";
  $thmb = "$base/thumbs";
  if (!is_dir($orig)) @mkdir($orig,0777,true);
  if (!is_dir($thmb)) @mkdir($thmb,0777,true);

  $added=[];
  foreach($_FILES['photos']['tmp_name'] as $i=>$tmp){
    if ($_FILES['photos']['error'][$i]!==UPLOAD_ERR_OK) continue;
    $ext=getExtFromMime($_FILES['photos']['type'][$i]);
    $name=uniqid('img_').'.'.$ext;
    $pOrig="$orig/$name"; $pTh="$thmb/$name";
    if(move_uploaded_file($tmp,$pOrig)){
      makeThumb($pOrig,$pTh,400,400);
      $added[]=$name;
    }
  }
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['status'=>'ok','files'=>$added]);
  exit;
}

/* === Секции анкеты === */
$SECTIONS = [
 'Детство'=>[
   'childhood_memories'=>'Где родился и какие воспоминания связаны с этим местом?',
   'family_relations'=>'Какие отношения царили в семье?',
   'childhood_qualities'=>'Какие качества проявлялись в детстве?'
 ],
 'Школа'=>[
   'bright_memories'=>'Какие яркие воспоминания из детства?',
   'school_period'=>'Как проходил школьный период?',
   'school_hobbies'=>'Какие были увлечения в школе?',
   'school_values'=>'Какие ценности формировались в школе?',
   'school_dreams'=>'О чем мечтал в школьные годы?'
 ],
 'Юность'=>[
   'after_school'=>'Чем занялся после школы?',
   'next_period'=>'Как проходил следующий период жизни?',
   'hobbies_changes'=>'Как менялись увлечения со временем?',
   'free_time'=>'Как проводил свободное время?'
 ],
 'Семья и характер'=>[
   'family_relations_adult'=>'Какие были семейные отношения во взрослой жизни?',
   'character_qualities'=>'Какие качества характера проявлялись?',
   'goals_achievement'=>'Какие цели ставил и достигал?'
 ],
 'Служба'=>[
   'front_reason'=>'Почему оказался на фронте?',
   'military_position'=>'Какая была военная должность?',
   'military_character'=>'Какие качества проявлялись на службе?',
   'military_stories'=>'Какие запомнились истории со службы?'
 ],
 'Память'=>[
   'last_days'=>'Как проходили последние дни?',
   'last_moments'=>'Какие были последние моменты?',
   'awards'=>'Какие награды имел?',
   'creativity'=>'Занимался ли творчеством?'
 ]
];

/* === Уже загруженные фото === */
$thumbs=[];
$thumbDir=__DIR__."/uploads/$hash/thumbs";
if(is_dir($thumbDir)){
 foreach(scandir($thumbDir) as $f){
   if($f==='.'||$f==='..') continue;
   $thumbs[]=$f;
 }
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>Анкета памяти</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
:root{--bg:#f5f5f7;--card:#fff;--border:#d2d2d7;--text:#1d1d1f;--primary:#007aff;}
*{box-sizing:border-box}
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;background:var(--bg);color:var(--text);padding-top:70px;padding-bottom:70px}
.container{max-width:960px;margin:0 auto;padding:16px}
.card{background:var(--card);border:1px solid var(--border);border-radius:20px;box-shadow:0 4px 20px rgba(0,0,0,.05);padding:20px;margin:16px 0}
h1{margin:0 0 16px;font-size:24px;font-weight:700}
h2{margin:12px 0;font-size:18px;font-weight:600}
label{display:block;font-weight:600;margin:10px 0 6px}
textarea,input[type=text]{width:100%;padding:12px;border:1px solid var(--border);border-radius:12px;font-size:16px;background:#fff}
textarea{min-height:90px;resize:vertical}
.btn{display:inline-flex;align-items:center;gap:6px;background:var(--primary);color:#fff;border:none;border-radius:12px;padding:10px 14px;font-weight:600;cursor:pointer}
.btn.secondary{background:#e5e5ea;color:#000}
.btn i{font-size:14px}
.photos{display:flex;flex-wrap:wrap;gap:10px;margin-top:12px}
.photo{position:relative}
.photo img{width:100px;height:100px;object-fit:cover;border-radius:12px;border:1px solid var(--border)}
.photo .del{position:absolute;top:-8px;right:-8px;background:#fff;border:1px solid var(--border);width:24px;height:24px;border-radius:50%;display:grid;place-items:center;color:#ff3b30;cursor:pointer}
.note{font-size:14px;color:#666}

/* фиксированная шапка */
.header{position:fixed;top:0;left:0;right:0;background:rgba(255,255,255,.95);backdrop-filter:blur(10px);border-bottom:1px solid var(--border);padding:10px 16px;z-index:1000}
.header-inner{max-width:960px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}
.header-title{font-size:20px;font-weight:700}
.header-actions{display:flex;gap:8px;flex-wrap:wrap}

/* нижняя навигация */
.footer{position:fixed;bottom:0;left:0;right:0;background:rgba(255,255,255,.95);backdrop-filter:blur(10px);border-top:1px solid var(--border);padding:10px 16px;z-index:999}
.footer-inner{max-width:960px;margin:0 auto;display:flex;justify-content:center}
.tabs{display:flex;gap:8px;overflow:auto}
.tab{white-space:nowrap;border:1px solid var(--border);border-radius:999px;padding:6px 12px;background:#fff;color:#000;font-weight:600;cursor:pointer;font-size:14px}
.tab.active{background:var(--primary);color:#fff;border:none}

/* тосты */
.toast-wrap{position:fixed;right:16px;bottom:90px;display:flex;flex-direction:column;gap:10px;z-index:2000}
.toast{background:#fff;border:1px solid var(--border);border-left:6px solid #34c759;padding:10px 14px;border-radius:12px;box-shadow:0 4px 14px rgba(0,0,0,.12);font-size:14px}

/* адаптив */
@media(max-width:600px){
 .header-inner{flex-direction:column;align-items:flex-start}
 .header-actions{width:100%;flex-direction:column}
 .header-actions .btn{width:100%;justify-content:center}
 .tab{padding:6px 10px;font-size:12px}
}

/* Прогресс-бар */
.progress-bar {
    width: 100%;
    height: 20px;
    background: #e5e5ea;
    border-radius: 10px;
    overflow: hidden;
    margin: 10px 0;
}
.progress-fill {
    height: 100%;
    background: #34c759;
    border-radius: 10px;
    width: 0%;
    transition: width 0.3s ease;
}
.progress-text {
    text-align: center;
    font-size: 14px;
    color: #666;
}
</style>
</head>
<body>

<div class="header">
  <div class="header-inner">
    <div class="header-title">Анкета памяти</div>
    <div class="header-actions">
      <button class="btn secondary" id="saveBtn"><i class="fa-regular fa-floppy-disk"></i> Сохранить черновик</button>
        <form id="sendForm" method="post" style="display:inline">
            <input type="hidden" name="hash" value="<?= htmlspecialchars($hash) ?>">
            <input type="hidden" name="complete" value="1">
            <button class="btn" type="submit" id="submitBtn">
                <i class="fa-solid fa-paper-plane"></i> Отправить анкету
            </button>
        </form>
        
        <!-- Добавим прогресс-бар для отправки -->
        <div class="card" id="submit-progress-card" style="display:none;">
            <h2>Отправка анкеты</h2>
            <div class="progress-bar">
                <div class="progress-fill" id="submit-progress-fill"></div>
            </div>
            <div class="progress-text" id="submit-progress-text">Подготовка...</div>
        </div>
    </div>
  </div>
</div>



<div class="container">
  <div class="card">
    <h1>Информация о герое</h1>
    <label>ФИО Героя</label><input type="text" name="namesave" value="<?= htmlspecialchars($session['namesave']??'') ?>">
    <label>Кто заполняет</label><input type="text" name="name_poluchatel" value="<?= htmlspecialchars($session['name_poluchatel']??'') ?>">
    <label>Телефон</label><input type="text" name="Phone" value="<?= htmlspecialchars($session['Phone']??'') ?>">
    <div class="note">Черновик сохраняется автоматически каждые 2 секунды</div>
  </div>

  <?php foreach($SECTIONS as $secTitle=>$qs): ?>
    <div class="card section" id="sec-<?= md5($secTitle) ?>">
      <h2><?= htmlspecialchars($secTitle) ?></h2>
      <?php foreach($qs as $field=>$label): ?>
        <label><?= htmlspecialchars($label) ?></label>
        <textarea name="<?= $field ?>"><?= htmlspecialchars($session[$field]??'') ?></textarea>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>

  <div class="card">
    <h2>Фотографии</h2>
    <label class="btn secondary" for="photos"><i class="fa-regular fa-image"></i> Добавить фото</label>
    <input id="photos" type="file" multiple accept="image/*" style="display:none">
    <div class="note">Новые фото добавляются к уже загруженным. Старые можно удалить крестиком.</div>
    <div class="photos" id="photos-wrap">
      <?php foreach($thumbs as $f): ?>
        <div class="photo" data-name="<?= htmlspecialchars($f) ?>">
          <img src="/uploads/<?= htmlspecialchars($hash) ?>/thumbs/<?= htmlspecialchars($f) ?>" alt="">
          <div class="del" data-del="<?= htmlspecialchars($f) ?>"><i class="fa-solid fa-xmark"></i></div>
        </div>
      <?php endforeach; ?>
    </div>
    <!-- Добавить после блока с фотографиями -->
    <div class="card" id="upload-progress-card" style="display:none;">
        <h2>Загрузка фотографий</h2>
        <div class="progress-bar">
            <div class="progress-fill"></div>
        </div>
        <div class="progress-text">0%</div>
    </div>
  </div>
</div>

<div class="footer">
  <div class="footer-inner">
    <div class="tabs" id="tabs">
      <?php $i=0; foreach($SECTIONS as $secTitle=>$qs): $i++; ?>
        <div class="tab<?= $i===1?' active':'' ?>" data-target="#sec-<?= md5($secTitle) ?>"><?= htmlspecialchars($secTitle) ?></div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="toast-wrap" id="toasts"></div>

<script>
const hash=<?= json_encode($hash) ?>;
let lastPayload='';
function getData(){
 const fd=new FormData();
 fd.append('hash',hash);
 document.querySelectorAll('input[type=text],textarea').forEach(el=>fd.append(el.name,el.value));
 return fd;
}
function toast(msg){
 const el=document.createElement('div');
 el.className='toast'; el.textContent=msg;
 document.getElementById('toasts').appendChild(el);
 setTimeout(()=>el.remove(),2000);
}
function saveDraft(){
 const fd=getData();
 const plain=[...fd.entries()].map(([k,v])=>k+'='+v).join('&');
 if(plain===lastPayload) return;
 lastPayload=plain;
 fetch('/save_draft.php',{method:'POST',body:fd})
   .then(r=>r.json()).then(j=>{
     if(j.status==='ok') toast('Сохранено');
   });
}
setInterval(saveDraft,2000);

document.getElementById('saveBtn').addEventListener('click',()=>{
 fetch('/save_draft.php',{method:'POST',body:getData()})
   .then(r=>r.json()).then(j=>{
     toast(j.status==='ok'?'Черновик сохранён':'Ошибка');
   });
});

// табы
document.querySelectorAll('.tab').forEach(tab=>{
 tab.addEventListener('click',()=>{
   const tgt=document.querySelector(tab.dataset.target);
   if(tgt) tgt.scrollIntoView({behavior:'smooth',block:'start'});
 });
});

// фото добавление с прогресс-баром
const inp = document.getElementById('photos'), wrap = document.getElementById('photos-wrap');
const progressCard = document.getElementById('upload-progress-card');
const progressFill = progressCard.querySelector('.progress-fill');
const progressText = progressCard.querySelector('.progress-text');

inp.addEventListener('change', () => {
    if (!inp.files.length) return;
    
    progressCard.style.display = 'block';
    progressFill.style.width = '0%';
    progressText.textContent = '0%';
    
    const fd = new FormData();
    for (const f of inp.files) fd.append('photos[]', f);
    
    const xhr = new XMLHttpRequest();
    
    xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) {
            const percent = Math.round((e.loaded / e.total) * 100);
            progressFill.style.width = percent + '%';
            progressText.textContent = percent + '%';
        }
    });
    
    xhr.addEventListener('load', () => {
        setTimeout(() => {
            progressCard.style.display = 'none';
        }, 1000);
        
        try {
            const j = JSON.parse(xhr.responseText);
            if (j.status === 'ok') {
                j.files.forEach(name => {
                    const div = document.createElement('div');
                    div.className = 'photo';
                    div.dataset.name = name;
                    div.innerHTML = `<img src="/uploads/${hash}/thumbs/${name}"><div class="del" data-del="${name}"><i class="fa-solid fa-xmark"></i></div>`;
                    wrap.prepend(div);
                });
                toast('Фото загружены');
            } else {
                toast('Ошибка загрузки');
            }
        } catch (e) {
            toast('Ошибка обработки ответа');
        }
    });
    
    xhr.addEventListener('error', () => {
        progressCard.style.display = 'none';
        toast('Ошибка сети');
    });
    
    xhr.open('POST', '/form.php?hash=' + encodeURIComponent(hash) + '&upload=1');
    xhr.send(fd);
});

// фото удаление
wrap.addEventListener('click',e=>{
 const btn=e.target.closest('.del'); if(!btn) return;
 const name=btn.dataset.del;
 const fd=new FormData(); fd.append('hash',hash); fd.append('name',name);
 fetch('/delete_photo.php',{method:'POST',body:fd})
  .then(r=>r.json()).then(j=>{
    if(j.status==='ok'){
      wrap.querySelector('.photo[data-name="'+name+'"]').remove();
      toast('Фото удалено');
    }
  });
});

// Обработчик отправки формы
document.getElementById('sendForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const submitBtn = document.getElementById('submitBtn');
    const progressCard = document.getElementById('submit-progress-card');
    const progressFill = document.getElementById('submit-progress-fill');
    const progressText = document.getElementById('submit-progress-text');
    
    // Блокируем кнопку
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Отправка...';
    progressCard.style.display = 'block';
    
    // Имитация прогресса (так как реальный прогресс сложно отслеживать для разных операций)
    let progress = 0;
    const progressInterval = setInterval(() => {
        progress += 5;
        if (progress <= 80) {
            progressFill.style.width = progress + '%';
            progressText.textContent = progress + '% - Отправка данных...';
        }
    }, 300);
    
    const formData = new FormData(this);
    
    fetch(this.action, {
        method: 'POST',
        body: formData
    })
    .then(response => {
        clearInterval(progressInterval);
        progressFill.style.width = '100%';
        progressText.textContent = '100% - Завершение...';
        
        if (response.redirected) {
            // Если редирект, значит успех
            setTimeout(() => {
                window.location.href = response.url;
            }, 1000);
        } else if (response.ok) {
            return response.text().then(text => {
                // Пытаемся обработать как JSON или показать текст ошибки
                try {
                    const data = JSON.parse(text);
                    if (data.redirect) {
                        window.location.href = data.redirect;
                    }
                } catch {
                    // Если не JSON, показываем ошибку
                    progressText.textContent = 'Ошибка: ' + text.substring(0, 100);
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Отправить анкету';
                }
            });
        } else {
            throw new Error('HTTP error ' + response.status);
        }
    })
    .catch(error => {
        clearInterval(progressInterval);
        progressText.textContent = 'Ошибка отправки: ' + error.message;
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Отправить анкету';
        toast('Ошибка отправки: ' + error.message);
    });
});

// ===== Подсветка активного раздела при скролле =====
const tabs = document.querySelectorAll('.tab');
const sections = document.querySelectorAll('.section');

const io = new IntersectionObserver((entries)=>{
  // берём самую большую по площади пересечения секцию
  const vis = entries.filter(e=>e.isIntersecting)
                     .sort((a,b)=>b.intersectionRatio - a.intersectionRatio)[0];
  if (!vis) return;
  const id = '#' + vis.target.id;
  tabs.forEach(t=>{
    t.classList.toggle('active', t.dataset.target === id);
  });
},{
  rootMargin: '-40% 0px -50% 0px',
  threshold: [0, .25, .5, .75, 1]
});

sections.forEach(sec=>io.observe(sec));

</script>
</body>
</html>