<?php
function escapeMarkdown($text) {
    if (!is_string($text)) return '';
    $characters = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!'];
    foreach ($characters as $char) {
        $text = str_replace($char, '\\' . $char, $text);
    }
    return $text;
}

function createTelegramTopic($heroName) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/createForumTopic";
    
    $topicName = "🎖️ " . mb_substr($heroName, 0, 30) . (mb_strlen($heroName) > 30 ? '...' : '');
    
    $data = [
        'chat_id' => BIOGRAPHY_FORUM_CHAT_ID, // Èñïîëüçóåì ôîðóì äëÿ áèîãðàôèé
        'name' => $topicName,
        'icon_color' => 0x6FB9F0
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200) {
        $response = json_decode($result, true);
        return $response['result']['message_thread_id'] ?? null;
    }
    
    return null;
}

function sendToTelegramTopic($message, $topicId = null, $photos = []) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    
    $data = [
        'chat_id' => BIOGRAPHY_FORUM_CHAT_ID, // Îòïðàâëÿåì â ôîðóì áèîãðàôèé
        'text' => $message,
        'parse_mode' => 'Markdown',
        'disable_web_page_preview' => true
    ];
    
    if ($topicId) {
        $data['message_thread_id'] = $topicId;
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    // Îòïðàâëÿåì ôîòîãðàôèè åñëè åñòü
    if (!empty($photos) && $topicId) {
        sendPhotosToTopic($photos, $topicId);
    }
    
    return $httpCode === 200;
}

function sendPhotosToTopic($photos, $topicId) {
    $successCount = 0;
    
    foreach ($photos as $index => $photo) {
        if (isset($photo['data'])) {
            try {
                // Очищаем данные от префикса data:image/...
                $imageData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $photo['data']));
                
                if (!$imageData) {
                    file_put_contents('logs/telegram_debug.log', date('[Y-m-d H:i:s]') . " Failed to decode base64 image\n", FILE_APPEND);
                    continue;
                }
                
                $tempFile = tempnam(sys_get_temp_dir(), 'tg_photo_') . '.jpg';
                $bytesWritten = file_put_contents($tempFile, $imageData);
                
                if ($bytesWritten === false) {
                    file_put_contents('logs/telegram_debug.log', date('[Y-m-d H:i:s]') . " Failed to write temp file\n", FILE_APPEND);
                    continue;
                }
                
                $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendPhoto";
                
                $postData = [
                    'chat_id' => BIOGRAPHY_FORUM_CHAT_ID,
                    'message_thread_id' => $topicId,
                    'caption' => "Фото " . ($index + 1),
                    'photo' => new CURLFile($tempFile)
                ];
                
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_TIMEOUT, 30);
                
                $result = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                
                // Логируем результат
                file_put_contents('logs/telegram_debug.log', date('[Y-m-d H:i:s]') . " Photo " . ($index + 1) . " - HTTP: " . $httpCode . " - Result: " . $result . "\n", FILE_APPEND);
                
                curl_close($ch);
                
                if ($httpCode === 200) {
                    $successCount++;
                }
                
                // Удаляем временный файл
                unlink($tempFile);
                sleep(1); // Пауза между отправками
                
            } catch (Exception $e) {
                file_put_contents('logs/telegram_debug.log', date('[Y-m-d H:i:s]') . " Photo error: " . $e->getMessage() . "\n", FILE_APPEND);
            }
        }
    }
    
    return $successCount;
}

function sendTelegramMessage($chatId, $message) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'Markdown',
        'disable_web_page_preview' => true
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return $httpCode === 200;
}

// Ôóíêöèÿ äëÿ îòïðàâêè â ÷àò óâåäîìëåíèé
function sendNotification($message) {
    return sendTelegramMessage(NOTIFICATION_CHAT_ID, $message);
}

// Ôóíêöèÿ äëÿ îòïðàâêè â ôîðóì áèîãðàôèé
function sendToBiographyForum($message, $topicId = null) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    
    $data = [
        'chat_id' => BIOGRAPHY_FORUM_CHAT_ID,
        'text' => $message,
        'parse_mode' => 'Markdown',
        'disable_web_page_preview' => true
    ];
    
    if ($topicId) {
        $data['message_thread_id'] = $topicId;
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return $httpCode === 200;
}
?>