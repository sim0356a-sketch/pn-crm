<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <title>Память Народов</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root {
      --accent:#2687c0;
      --text:#1d1d1f;
      --muted:#6e6e73;
    }
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
         background:#fff;color:var(--text);line-height:1.4;overflow-x:hidden}

    /* меню */
    header {
      position:fixed;top:20px;left:50%;transform:translateX(-50%);
      z-index:1000;
    }
    .menu-island {
      position:relative;display:flex;align-items:center;gap:24px;
      padding:10px 24px;background:rgba(0,0,0,.85);backdrop-filter:blur(12px);
      border-radius:50px;box-shadow:0 6px 20px rgba(0,0,0,.25);
    }
    nav {display:flex;gap:20px;position:relative}
    nav a {
      position:relative;
      color:#fff;
      text-decoration:none;
      font-weight:500;
      font-size: clamp(12px, 1vw, 15px); /* вот оно */
      padding:6px 12px;
      border-radius:12px;
      z-index:2;
      transition:.3s;
    }
    /* рукописный шрифт */
    @font-face {
  font-family: 'Shadows Into Light';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/shadowsintolight/v22/UqyNK9UOIntux_czAvDQx_ZcHqZXBNQze8D55TecYeIo.woff2) format('woff2');
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
  }
  /* latin */
  @font-face {
    font-family: 'Shadows Into Light';
    font-style: normal;
    font-weight: 400;
    font-display: swap;
    src: url(https://fonts.gstatic.com/s/shadowsintolight/v22/UqyNK9UOIntux_czAvDQx_ZcHqZXBNQzdcD55TecYQ.woff2) format('woff2');
    unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
  }
    
    .handwrite {
      font-family: 'Shadows Into Light';
      font-size: 22px;
      margin-bottom: 10px;
      display: block;
      color: #fff;
    }
    
    .scroll-down {
      position: absolute;
      bottom: 40px;
      left: 50%;
      transform: translateX(-50%);
      text-align: center;
      cursor: pointer;
      color: #000;
      opacity: 0.7;
      transition: opacity .3s;
    }
    .scroll-down:hover {opacity: 1}
    
    .arrow-down {
      display: block;
      margin: 0 auto;
      animation: bounce 1.8s infinite;
    }
    
    /* анимация стрелки */
    @keyframes bounce {
      0%, 20%, 50%, 80%, 100% {transform: translateY(0)}
      40% {transform: translateY(8px)}
      60% {transform: translateY(4px)}
    }
    nav a:hover{color:var(--accent)}
    .menu-highlight {
      position:absolute;top:0;bottom:0;border-radius:50px;
      background:rgba(255,255,255,.25);z-index:1;
      transition:all .3s cubic-bezier(.4,.2,.2,1);
    }

    /* секции в стиле Apple */
    section{min-height:100vh;display:flex;flex-direction:column;
            justify-content:center;align-items:center;
            padding:120px 20px;text-align:center;margin:0 auto}

    h1 {
      font-size: clamp(32px, 6vw, 72px); /* min, prefer, max */
    }
    h2 {
      font-size: clamp(24px, 4vw, 48px);
    }
    p {
      font-size: clamp(16px, 2vw, 20px);
    }
    img{margin:40px auto;border-radius:20px;box-shadow:0 8px 30px rgba(0,0,0,.1)}

    .btn{display:inline-block;margin-top:20px;padding:16px 32px;
         font-size:18px;font-weight:600;color:#fff;background:var(--accent);
         border:none;border-radius:12px;text-decoration:none;transition:.3s}
    .btn:hover{background:#1b6ea3}

    /* анимации */
    [data-animate]{opacity:0;transform:translateY(60px);transition:all .8s ease}
    [data-animate].visible{opacity:1;transform:translateY(0)}

    @media(max-width:768px){
      h1{font-size:42px}
      h2{font-size:28px}
      p{font-size:16px}
    }
    .dark-section {
      background:#000;     /* фон на всю ширину */
      color:#fff;
      width:100%;          /* растянуть по горизонтали */
    }
    
    .dark-section .content {
      max-width:1200px;    /* ограничиваем текст */
      margin:0 auto;
      padding:100px 20px;
      text-align:center;
    }
    
    .dark-section p {color:#ccc;}
    #intro {
  position: relative;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  background: #fff;
  color: #000;

  /* фон снизу */
  background-image: url("images/bg2.png");
  background-repeat: no-repeat;
  background-position: bottom center;
  background-size: 100% auto; /* растягиваем по ширине */
}

.intro-content {
  z-index: 2;
  padding: 40px 20px;
}

.scroll-down {
  position: absolute;
  bottom: 40px;
  left: 50%;
  transform: translateX(-50%);
  text-align: center;
  cursor: pointer;
  color: #fff;
  opacity: 0.7;
  transition: opacity .3s;
}
.scroll-down:hover {opacity: 1}

  </style>
</head>
<body>

<header>
  <div class="menu-island">
    <nav id="menu">
      <span class="menu-highlight"></span>
      <a href="#intro">Главная</a>
      <a href="#about">О нас</a>
      <a href="#values">Ценности</a>
      <a href="/representatives_rating.php">Рейтинг</a>
      <a href="#join">Присоединиться</a>
    </nav>
  </div>
</header>

<section id="intro">
  <div class="intro-content">
  <h1 data-animate>Каждая история имеет значение</h1>
  <p data-animate>Мы сохраняем память о людях, ведь их жизнь — это не только личная история, но и часть истории народов.</p>
  </div>

  <div class="scroll-down" onclick="document.getElementById('about').scrollIntoView({behavior:'smooth'})">
    <span class="handwrite">Больше информации ниже</span>
    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="arrow-down">
      <path d="M6 9l12 12 12-12"/>
    </svg>
  </div>
</section>


<!-- 2 экран -->
<section id="about" class="dark-section">
  <h2 data-animate>Что мы делаем?</h2>
  <p data-animate>«Память Народов» помогает семьям сохранить истории: мы пишем биографии, обрабатываем фотографии, создаём цифровые страницы и производим QR-шильды. Предпринимаем усилия, что бы память осталась спустя десятилетия и передавалась целостной из первых уст.</p>
</section>

<!-- 3 экран -->
<section id="values">
  <h2 data-animate>Наши ценности</h2>
  <p data-animate>Мы верим, что каждая история достойна быть сохраненной.</p>
  <div style="display:flex;flex-wrap:wrap;gap:40px;justify-content:center;margin-top:40px">
    <div style="flex:1 1 260px;min-width:260px" data-animate>
      <h3>Биографии</h3>
      <p>Оформляем воспоминания в тексты и фото, которые будут доступны десятилетиями.</p>
    </div>
    <div style="flex:1 1 260px;min-width:260px" data-animate>
      <h3>Жетоны</h3>
      <p>Каждый жетон — знак благодарности за вклад. Твоё имя сохраняется вместе с историей.</p>
    </div>
    <div style="flex:1 1 260px;min-width:260px" data-animate>
      <h3>QR-шильды</h3>
      <p>QR-код на памятнике открывает доступ к биографии и связывает поколения.</p>
    </div>
    <div style="flex:1 1 260px;min-width:260px" data-animate>
      <h3>Сообщество</h3>
      <p>Ты становишься частью движения «Память Народов», где ценится каждый шаг.</p>
    </div>
    <div>
      <p class="intro-content" data-animate><strong>Важно:</strong> шильды памяти — не только для участников СВО. Это могут быть родители, бабушки и дедушки, учителя и любые близкие, чью память важно сохранить.</p>
    </div>
  </div>
</section>

<!-- 4 экран -->
<section id="join">
  <h2 data-animate>Присоединяйся к движению</h2>
  <p data-animate>Стань частью «Память Народов» и помогая другим сохранять историю, получай за это ценные подарки.</p>
  <a href=/become_representative.php class="btn" data-animate>Стать участником</a>
</section>

<footer style="text-align:center;font-size:14px;color:var(--muted);padding:40px 20px">
  © 2025 Движение «Память Народов». Все права защищены.
</footer>

<script>
  // подсветка меню
  const menu=document.getElementById('menu');
  const highlight=menu.querySelector('.menu-highlight');
  const links=menu.querySelectorAll('a');

  function setHighlight(el){
    const rect=el.getBoundingClientRect();
    const parentRect=menu.getBoundingClientRect();
    highlight.style.width=rect.width+'px';
    highlight.style.left=(rect.left-parentRect.left)+'px';
  }
  function activateLink(id){
    links.forEach(link=>{
      if(link.getAttribute('href')==='#'+id){setHighlight(link);}
    });
  }
  const sections=document.querySelectorAll('section');
  window.addEventListener('scroll',()=>{
    let current="";
    sections.forEach(sec=>{
      if(window.scrollY>=sec.offsetTop-200){current=sec.getAttribute("id");}
    });
    if(current){activateLink(current);}
  });
  setHighlight(links[0]);

  // анимации при скролле
  const items=document.querySelectorAll("[data-animate]");
  const observer=new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting) entry.target.classList.add("visible");
    });
  },{threshold:.2});
  items.forEach(el=>observer.observe(el));
</script>

</body>
</html>
