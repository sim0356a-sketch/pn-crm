<?php
function extractUserIdsFromHtml($htmlContent) {
    $pattern = '/id_user_(\d+)/';
    preg_match_all($pattern, $htmlContent, $matches);
    
    if (isset($matches[1]) && !empty($matches[1])) {
        // Убираем дубликаты и возвращаем уникальные ID
        return array_unique($matches[1]);
    }
    
    return [];
}

function saveIdsToFile($userIds, $filename = 'user_ids.txt') {
    $count = count($userIds);
    file_put_contents($filename, implode("\n", $userIds));
    return $count;
}

// Основная логика
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['html_file'])) {
    $uploadedFile = $_FILES['html_file'];
    
    if ($uploadedFile['error'] === UPLOAD_ERR_OK) {
        $htmlContent = file_get_contents($uploadedFile['tmp_name']);
        $userIds = extractUserIdsFromHtml($htmlContent);
        $count = saveIdsToFile($userIds);
        
        echo "<h3>Успешно извлечено ID: $count</h3>";
        echo "<p>ID сохранены в файл: user_ids.txt</p>";
        echo "<a href='user_ids.txt' download>Скачать файл с ID</a>";
    } else {
        echo "Ошибка загрузки файла: " . $uploadedFile['error'];
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Извлечение ID пользователей VK</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .container { max-width: 600px; margin: 0 auto; }
        .upload-form { border: 2px dashed #ccc; padding: 20px; text-align: center; }
        .btn { background: #007bff; color: white; padding: 10px 20px; border: none; cursor: pointer; }
        .btn:hover { background: #0056b3; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Извлечение ID пользователей из HTML VK</h1>
        
        <div class="upload-form">
            <form method="POST" enctype="multipart/form-data">
                <h3>Загрузите HTML файл со страницы участников группы</h3>
                <input type="file" name="html_file" accept=".html,.htm" required>
                <br><br>
                <button type="submit" class="btn">Извлечь ID</button>
            </form>
        </div>

        <div style="margin-top: 30px;">
            <h3>Как использовать:</h3>
            <ol>
                <li>Откройте страницу участников группы ВК</li>
                <li>Прокрутите до конца, чтобы подгрузить всех участников</li>
                <li>Сохраните страницу: Ctrl+S → выбирайте "Веб страница, полностью"</li>
                <li>Загрузите сохраненный HTML файл выше</li>
            </ol>
        </div>
    </div>
</body>
</html>