<?php include '../includes/auth.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Память Народов</title>
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", sans-serif;
      background: #f5f5f7;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      text-align: center;
      color: #1d1d1f;
    }
    .container {
      max-width: 600px;
      padding: 40px;
    }
    h1 {
      font-size: 32px;
      margin-bottom: 20px;
    }
    p {
      font-size: 18px;
      margin-bottom: 30px;
    }
    a {
      background: #0071e3;
      color: #fff;
      padding: 14px 24px;
      border-radius: 12px;
      text-decoration: none;
      font-weight: 600;
      transition: 0.2s;
    }
    a:hover {
      background: #0077ED;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Память Народов</h1>
    <p>Сохраним истории, которые важны для будущих поколений.</p>
    <a href="form.php">Заполнить анкету</a>
  </div>
</body>
</html>
