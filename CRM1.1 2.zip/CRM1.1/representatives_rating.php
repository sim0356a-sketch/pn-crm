<?php
require __DIR__.'/config.php';

// Загружаем активных представителей по заказам
$stmt = $pdo->query("SELECT id, full_name, photo_path, orders_count, promo_code 
                     FROM representatives 
                     WHERE is_active=1 
                     ORDER BY orders_count DESC 
                     LIMIT 12");
$reps = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <title>Наши участники — Память Народов</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root {--accent:#2687c0;--text:#1d1d1f;--muted:#6e6e73;}
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
         background:#fff;color:var(--text);line-height:1.4;overflow-x:hidden}
    header{position:fixed;top:20px;left:50%;transform:translateX(-50%);z-index:1000}
    .menu-island{display:flex;gap:24px;padding:10px 24px;background:rgba(0,0,0,.85);
                 backdrop-filter:blur(12px);border-radius:50px;box-shadow:0 6px 20px rgba(0,0,0,.25)}
    nav{display:flex;gap:20px}
    nav a{color:#fff;text-decoration:none;font-weight:500;font-size:clamp(12px,2vw,15px);
          padding:6px 12px;border-radius:12px;transition:.3s}
    nav a:hover{color:var(--accent)}

    section{min-height:100vh;display:flex;flex-direction:column;justify-content:center;align-items:center;
            padding:120px 20px;text-align:center;max-width:1200px;margin:0 auto}
    h1{font-size:clamp(32px,6vw,72px);font-weight:700;margin-bottom:20px}
    p{font-size:clamp(16px,2vw,20px);color:var(--muted)}

    .reps-grid {
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
      gap:30px;width:100%;max-width:1000px;margin:40px auto;
    }
    .rep-card {
      background:#f9f9f9;border-radius:20px;padding:20px;text-align:center;
      box-shadow:0 6px 20px rgba(0,0,0,.05);transition:.3s;
    }
    .rep-card:hover{transform:translateY(-5px)}
    .rep-card img{width:120px;height:120px;border-radius:50%;object-fit:cover;margin-bottom:15px;border:2px solid #eee}
    .rep-placeholder{width:120px;height:120px;margin:0 auto 15px;display:flex;align-items:center;justify-content:center;border-radius:50%;background:#ddd;font-size:48px}
    .rep-card h3{font-size:20px;font-weight:600;margin-bottom:8px}
    .rep-card p{font-size:16px;color:var(--accent);font-weight:500}
  </style>
</head>
<body>

<header>
  <div class="menu-island">
    <nav>
      <a href="/index.php">Главная</a>
      <a href="/representatives_rating.php">Рейтинг</a>
      <a href="/become_representative.php">Стать участником</a>
    </nav>
  </div>
</header>

<section>
  <h1>Наши участники</h1>
  <p>Люди, которые помогают сохранять память.</p>

  <?php if ($reps): ?>
    <div class="reps-grid">
      <?php foreach ($reps as $rep): ?>
        <div class="rep-card">
          <?php if (!empty($rep['photo_path'])): ?>
            <img src="<?= htmlspecialchars($rep['photo_path']) ?>" alt="<?= htmlspecialchars($rep['full_name']) ?>">
          <?php else: ?>
            <div class="rep-placeholder">👤</div>
          <?php endif; ?>
          <h3><?= htmlspecialchars($rep['full_name']) ?></h3>
          <p>⭐ <?= (int)$rep['orders_count'] ?> заказов</p>
          <small style="color:#6e6e73">Промокод: <?= htmlspecialchars($rep['promo_code']) ?></small>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <p>Пока нет активных Участников.</p>
  <?php endif; ?>
</section>

</body>
</html>
