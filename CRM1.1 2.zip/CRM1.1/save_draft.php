<?php
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/config.php';

$hash = $_POST['hash'] ?? '';
if (!$hash) { echo json_encode(['status'=>'error','message'=>'no hash']); exit; }

// белый список полей анкеты + шапка
$fields = [
  'namesave','name_poluchatel','Phone',
  'childhood_memories','family_relations','childhood_qualities',
  'bright_memories','school_period','school_hobbies','school_values','school_dreams',
  'after_school','next_period','hobbies_changes','free_time',
  'family_relations_adult','character_qualities','goals_achievement',
  'front_reason','military_position','military_character','military_stories',
  'last_days','last_moments','awards','creativity'
];

$sets = []; $vals = [];
foreach ($fields as $f) {
  if (array_key_exists($f, $_POST)) {
    $sets[] = "`$f` = ?";
    $vals[] = trim((string)$_POST[$f]);
  }
}
$sets[] = "updated_at = NOW()";
$vals[] = $hash;

if (count($vals) === 1) { echo json_encode(['status'=>'ok']); exit; } // нечего обновлять

$sql = "UPDATE form_sessions SET ".implode(',', $sets)." WHERE hash = ?";
try {
  $stmt = $pdo->prepare($sql);
  $stmt->execute($vals);
  echo json_encode(['status'=>'ok']);
} catch (Throwable $e){
  error_log('save_draft error: '.$e->getMessage());
  echo json_encode(['status'=>'error','message'=>'db']);
}