
<?php
require __DIR__.'/config.php';


// === Получаем данные из формы ===
$name  = trim($_POST['full_name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');

// Проверка обязательных полей
if ($name === '' || $phone === '' || $email === '') {
    die("Ошибка: заполните все поля!");
}

// === Промокод из файла ===
$file = __DIR__ . "/promocodes.txt";

// Читаем все строки
$codes = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

if (!$codes || count($codes) === 0) {
    die("Нет доступных промокодов!");
}

// Берём первый код
$promo = trim($codes[0]);

// Удаляем его из массива
array_shift($codes);

// Перезаписываем файл без использованного кода
file_put_contents($file, implode("\n", $codes));

// === Обработка фото ===
$photo_path = null;
if (!empty($_FILES['photo']['name'])) {
    $uploadDir = __DIR__ . "/uploads/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
    $fileName = uniqid("rep_").".".$ext;
    $targetFile = $uploadDir.$fileName;

    if (move_uploaded_file($_FILES['photo']['tmp_name'], $targetFile)) {
        $photo_path = "uploads/".$fileName;
    }
}

// === Сохраняем в БД ===
$stmt = $pdo->prepare("INSERT INTO representatives (full_name, phone, photo_path, promo_code, orders_count, total_orders, is_active) 
                       VALUES (?,?,?,?,0,0,1)");
$stmt->execute([$name, $phone, $photo_path, $promo]);

// === Отправляем в Telegram ===
$managerMessage .=  "📩 Новая заявка представителя\n\n";
$managerMessage .=  "👤 Имя: $name\n\n";
$managerMessage .=  "📞 Телефон: $phone\n\n";
$managerMessage .=  "📧 Email: $email\n\n";
$managerMessage .=  "Мы ислючительно благодарим Вас за проявленный интерес и помощь нашему проекту, напоминием Ваш промокод: $promo.\n\n";
$managerMessage .=  "Присоединяйтесь к первым участникам нашего движения в телеграм: https://t.me/+mulJTXjmJhAxYzky\n\n";

sendManagerTelegramMessage($managerMessage);

?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <title>Спасибо — Память Народов</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
      display:flex;justify-content:center;align-items:center;
      height:100vh;margin:0;background:#fff;color:#1d1d1f;text-align:center;
    }
    h1 {font-size:clamp(28px,5vw,48px);margin-bottom:20px;}
    p {font-size:clamp(16px,2vw,20px);color:#6e6e73;}
    .promo {margin-top:20px;font-size:clamp(18px,3vw,24px);font-weight:700;color:#2687c0;}
    a {display:inline-block;margin-top:30px;padding:14px 24px;
       background:#2687c0;color:#fff;text-decoration:none;
       border-radius:12px;font-weight:600;}
  </style>
</head>
<body>
  <div>
    <h1>Спасибо за заявку!</h1>
    <p>Наш менеджер скоро свяжется с Вами и пришлет ссылку на группу с информацией.</p>
    <div class="promo">Ваш промокод: <?= htmlspecialchars($promo) ?></div>
    <a href="/representatives_rating.php">Посмотреть рейтинг</a>
  </div>
</body>
</html>




<?php
require __DIR__.'/config.php';


// === Получаем данные из формы ===
$name  = trim($_POST['full_name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');

// Проверка обязательных полей
if ($name === '' || $phone === '' || $email === '') {
    die("Ошибка: заполните все поля!");
}

// === Генерация промокода ===
$promo = strtoupper("PN-".substr(md5($name.$phone.time()), 0, 6));

// === Обработка фото ===
$photo_path = null;
if (!empty($_FILES['photo']['name'])) {
    $uploadDir = __DIR__ . "/uploads/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
    $fileName = uniqid("rep_").".".$ext;
    $targetFile = $uploadDir.$fileName;

    if (move_uploaded_file($_FILES['photo']['tmp_name'], $targetFile)) {
        $photo_path = "uploads/".$fileName;
    }
}

// === Сохраняем в БД ===
$stmt = $pdo->prepare("INSERT INTO representatives (full_name, phone, photo_path, promo_code, orders_count, total_orders, is_active) 
                       VALUES (?,?,?,?,0,0,1)");
$stmt->execute([$name, $phone, $photo_path, $promo]);

// === Отправляем в Telegram ===
$managerMessage .=  "📩 Новая заявка представителя\n\n";
$managerMessage .=  "👤 Имя: $name\n\n";
$managerMessage .=  "📞 Телефон: $phone\n\n";
$managerMessage .=  "📧 Email: $email\n\n";
$managerMessage .=  "🎟 Промокод: $promo";

sendManagerTelegramMessage($managerMessage);

?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <title>Спасибо — Память Народов</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
      display:flex;justify-content:center;align-items:center;
      height:100vh;margin:0;background:#fff;color:#1d1d1f;text-align:center;
    }
    h1 {font-size:clamp(28px,5vw,48px);margin-bottom:20px;}
    p {font-size:clamp(16px,2vw,20px);color:#6e6e73;}
    .promo {margin-top:20px;font-size:clamp(18px,3vw,24px);font-weight:700;color:#2687c0;}
    a {display:inline-block;margin-top:30px;padding:14px 24px;
       background:#2687c0;color:#fff;text-decoration:none;
       border-radius:12px;font-weight:600;}
  </style>
</head>
<body>
  <div>
    <h1>Спасибо за заявку!</h1>
    <p>Наш менеджер скоро свяжется с вами.</p>
    <div class="promo">Ваш промокод: <?= htmlspecialchars($promo) ?></div>
    <a href="representatives_rating.php">Посмотреть рейтинг</a>
  </div>
</body>
</html>