<?php include '../includes/auth.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Спасибо | Память Народов</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", sans-serif;
      background: #f5f5f7;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      color: #1d1d1f;
    }
    .container {
      text-align: center;
      background: #fff;
      padding: 40px;
      border-radius: 20px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.1);
    }
    h1 {
      font-size: 28px;
      margin-bottom: 20px;
    }
    p {
      font-size: 18px;
    }
    a {
      display: inline-block;
      margin-top: 20px;
      padding: 14px 24px;
      background: #0071e3;
      color: #fff;
      border-radius: 12px;
      text-decoration: none;
      font-weight: 600;
    }
    a:hover {
      background: #0077ED;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Спасибо!</h1>
    <p>Ваши данные сохранены. Мы свяжемся с вами в ближайшее время.</p>
    <a href="index.php">На главную</a>
  </div>
</body>
</html>
