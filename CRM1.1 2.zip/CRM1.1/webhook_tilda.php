<?php
include 'config.php';

// --- Функции ---
function getRepresentativeByPromoCode($promoCode) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM representatives WHERE promo_code = ?");
    $stmt->execute([$promoCode]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function incrementRepresentativeOrders($repId) {
    global $pdo;
    $pdo->prepare("UPDATE representatives SET orders_count = orders_count + 1 WHERE id = ?")
        ->execute([$repId]);
    $stmt = $pdo->prepare("SELECT * FROM representatives WHERE id = ?");
    $stmt->execute([$repId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// --- Получаем данные ---
$input = file_get_contents('php://input');
parse_str($input, $data);

// --- Сразу отвечаем Тильде ---
header('Content-Type: application/json');
echo json_encode([
    'status' => 'success',
    'message' => 'Анкета создана успешно'
]);

// Отправляем ответ клиенту, но продолжаем скрипт
if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
}
ignore_user_abort(true);

// --- Логируем входящие данные (асинхронно) ---
file_put_contents('tilda_webhook.log', date('Y-m-d H:i:s') . " - Webhook received\n", FILE_APPEND);
file_put_contents('tilda_webhook.log', "Raw data: " . $input . "\n", FILE_APPEND);

// --- Основная логика ---
if ($data && isset($data['namesave'])) {
    $namesave = $data['namesave'];
    $name_poluchatel = $data['name_poluchatel'] ?? 'Не указано';
    $phone = $data['Phone'] ?? 'Не указан';
    $order_id = $data['payment']['orderid'] ?? 'Не указан';
    $email = $data['Email'] ?? 'Не указан';

    // Промокод
    $promoCode = $data['payment']['promocode'] ?? null;
    if ($promoCode) {
        $promoCode = urldecode(trim($promoCode));
    }

    $hash = generateHash();

    try {
        // Сохраняем в БД
        $stmt = $pdo->prepare("INSERT INTO form_sessions 
            (hash, namesave, name_poluchatel, Phone, order_id, telegram_topic_id, promo_code) 
            VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$hash, $namesave, $name_poluchatel, $phone, $order_id, null, $promoCode]);

        $link = BASE_URL . '/form.php?hash=' . $hash;

        // --- Формируем сообщение ---
        $message = "";
        if ($promoCode) {
            $representative = getRepresentativeByPromoCode($promoCode);
            if ($representative) {
                $updatedRep = incrementRepresentativeOrders($representative['id']);
                $message .= "👥 <b>Представитель:</b> " . htmlspecialchars($updatedRep['full_name']) . "\n";
                $message .= "🎫 <b>Промокод:</b> " . htmlspecialchars($promoCode) . "\n";
                $message .= "📈 <b>Всего заказов у представителя:</b> " . $updatedRep['orders_count'] . "\n\n";
            }
        }

        // Список товаров
        $productsList = '';
        if (isset($data['payment']['products']) && is_array($data['payment']['products'])) {
            foreach ($data['payment']['products'] as $product) {
                $extId = $product['externalid'] ?? '';
                $title = $product['name'] ?? '';
                $count = $product['quantity'] ?? 1;
                $productsList .= "▪️ $title (ID: $extId), Кол-во: $count\n";
            }
        }

        $managerMessage = "🎯 <b>НОВАЯ ЗАЯВКА С TILDA</b>\n\n";
        $managerMessage .= "🎖️ <b>Герой:</b> " . htmlspecialchars($namesave) . "\n";
        $managerMessage .= "👤 <b>Заполняет:</b> " . htmlspecialchars($name_poluchatel) . "\n";
        $managerMessage .= "📞 <b>Телефон:</b> " . htmlspecialchars($phone) . "\n";
        $managerMessage .= "📧 <b>Email:</b> " . htmlspecialchars($email) . "\n";
        $managerMessage .= "📦 <b>Номер заказа:</b> " . htmlspecialchars($order_id) . "\n\n";

        if ($productsList) {
            $managerMessage .= "🛒 <b>Товары:</b>\n" . $productsList . "\n";
        }

        if ($message) {
            $managerMessage .= "\n" . $message . "\n";
        }

        $managerMessage .= "🔗 <b>Ссылка для заполнения анкеты:</b>\n" . $link . "\n\n";
        $managerMessage .= "⏰ <b>Время заявки:</b> " . date('d.m.Y H:i') . "\n\n";
        $managerMessage .= "💬 Заглавная фотография передана в работу.\n\n";
        $managerMessage .= "Для биографии заполните анкету: " . $link . "\n\n";
        $managerMessage .= "Подготовьте фото из разных периодов жизни (до 12 шт).";

        // Отправляем в Telegram (асинхронно)
        sendManagerTelegramMessage($managerMessage);

    } catch(PDOException $e) {
        file_put_contents('tilda_webhook.log', "DB ERROR: " . $e->getMessage() . "\n", FILE_APPEND);
    }
}
