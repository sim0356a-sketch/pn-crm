<?php
session_start();

// Настройки базы данных
define('DB_HOST', 'localhost');
define('DB_NAME', 'j18643707_anketnik');
define('DB_USER', '047436534_lolick');
define('DB_PASS', 'z{ps82@0=J[^l5_');

// Настройки Telegram
define('TELEGRAM_BOT_TOKEN', '7809374416:AAG5BnRIa9e_B99Xx9-koQAcQT5-x6nEXoA');
define('TELEGRAM_CHAT_ID', '-1003058720676');
define('TELEGRAM_MANAGER_CHAT_ID', '-1002350950452');


// Функция для проверки завершения анкеты
function isFormCompleted($hash) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT is_completed FROM form_sessions WHERE hash = ?");
        $stmt->execute([$hash]);
        $session = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $session && $session['is_completed'] == 1;
    } catch(PDOException $e) {
        error_log("Ошибка проверки завершения анкеты: " . $e->getMessage());
        return false;
    }
}

// Функция для обновления основных данных анкеты
function updateFormSessionData($hash, $data) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("UPDATE form_sessions 
                              SET namesave = ?, name_poluchatel = ?, Phone = ?, order_id = ?, updated_at = NOW() 
                              WHERE hash = ?");
        $stmt->execute([
            $data['namesave'], 
            $data['name_poluchatel'], 
            $data['Phone'], 
            $data['order_id'], 
            $hash
        ]);
        return true;
    } catch(PDOException $e) {
        error_log("Ошибка обновления данных: " . $e->getMessage());
        return false;
    }
}

// Функция для создания топика в Telegram с улучшенной обработкой ошибок
function createTelegramTopic($heroName) {
    // Проверяем, установлены ли необходимые константы
    if (!defined('TELEGRAM_BOT_TOKEN') || !defined('TELEGRAM_CHAT_ID')) {
        error_log("Telegram bot token or chat ID not defined");
        return null;
    }
    
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/createForumTopic";
    $data = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'name' => substr($heroName, 0, 255),
        'icon_color' => 7322096 // Синий цвет иконки
    ];
    
    // Логирование
    error_log("Creating Telegram topic for: " . $heroName);
    error_log("Request URL: " . $url);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Отключаем проверку SSL для тестирования
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    
    curl_close($ch);
    
    // Логирование ответа
    error_log("Telegram API response: " . $result);
    error_log("HTTP code: " . $httpCode);
    
    if ($error) {
        error_log("CURL error: " . $error);
        return null;
    }
    
    $response = json_decode($result, true);
    
    if (!$response) {
        error_log("Invalid JSON response from Telegram API");
        return null;
    }
    
    if (!$response['ok']) {
        error_log("Telegram API error: " . $response['description']);
        return null;
    }
    
    return $response['result']['message_thread_id'] ?? null;
}

// Функция отправки всех данных в Telegram с улучшенным логированием
function sendAllDataToTelegram($hash) {
    global $pdo;
    
    error_log("Starting sendAllDataToTelegram for hash: " . $hash);
    
    $stmt = $pdo->prepare("SELECT * FROM form_sessions WHERE hash = ?");
    $stmt->execute([$hash]);
    $session = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$session) {
        error_log("Session not found for hash: " . $hash);
        return false;
    }
    
    if (empty($session['telegram_topic_id'])) {
        error_log("No telegram_topic_id found for session: " . $hash);
        return false;
    }
    
    $message = "📋 <b>АНКЕТА ЗАПОЛНЕНА</b>\n\n";
    $message .= "🎖️ <b>Герой:</b> " . htmlspecialchars($session['namesave']) . "\n";
    $message .= "👤 <b>Заполнил:</b> " . htmlspecialchars($session['name_poluchatel']) . "\n";
    $message .= "📞 <b>Телефон:</b> " . htmlspecialchars($session['Phone']) . "\n";
    $message .= "📦 <b>Номер заказа:</b> " . htmlspecialchars($session['order_id'] ?? 'не указан') . "\n\n";
    
    $questions = [
        'childhood_memories' => 'Где родился и какие воспоминания связаны с этим местом?',
        'family_relations' => 'Какие отношения царили в семье?',
        'childhood_qualities' => 'Какие качества проявлялись в детстве?',
        'bright_memories' => 'Какие яркие воспоминания из детства?',
        'school_period' => 'Как проходил школьный период?',
        'school_hobbies' => 'Какие были увлечения в школе?',
        'school_values' => 'Какие ценности формировались в школе?',
        'school_dreams' => 'О чем мечтал в школьные годы?',
        'after_school' => 'Чем занялся после школы?',
        'next_period' => 'Как проходил следующий период жизни?',
        'hobbies_changes' => 'Как менялись увлечения со временем?',
        'free_time' => 'Как проводил свободное время?',
        'family_relations_adult' => 'Какие были семейные отношения во взрослой жизни?',
        'character_qualities' => 'Какие качества характера проявлялись?',
        'goals_achievement' => 'Какие цели ставил и достигал?',
        'front_reason' => 'Почему оказался на фронте?',
        'military_position' => 'Какая была военная должность?',
        'military_character' => 'Какие качества проявлялись на службе?',
        'military_stories' => 'Какие запомнились истории со службы?',
        'last_days' => 'Как проходили последние дни?',
        'last_moments' => 'Какие были последние моменты?',
        'awards' => 'Какие награды имел?',
        'creativity' => 'Занимался ли творчеством?'
    ];
    
    foreach ($questions as $field => $question) {
        if (!empty($session[$field])) {
            $message .= "❓ <b>" . $question . "</b>\n";
            $message .= "💬 " . htmlspecialchars($session[$field]) . "\n\n";
        }
    }
    
    // Отправляем текстовую информацию
    error_log("Sending text message to Telegram");
    $textResult = sendTelegramMessage($message, $session['telegram_topic_id']);
    error_log("Text message result: " . $textResult);
    
    // Отправляем фотографии
    $uploadDir = UPLOAD_DIR . $hash . '/';
    if (file_exists($uploadDir)) {
        $photos = scandir($uploadDir);
        $photoCount = 0;
        
        foreach ($photos as $photo) {
            if ($photo != '.' && $photo != '..') {
                $photoPath = $uploadDir . $photo;
                error_log("Sending photo: " . $photoPath);
                
                $photoResult = sendTelegramPhoto($photoPath, "📸 Фотография из анкеты", $session['telegram_topic_id']);
                error_log("Photo result: " . $photoResult);
                
                $photoCount++;
                sleep(1); // Задержка между отправками
            }
        }
        
        error_log("Sent " . $photoCount . " photos");
    } else {
        error_log("No upload directory found: " . $uploadDir);
    }
    
    return true;
}

function sendTelegramMessage($text, $topicId = null) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    $data = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    if ($topicId) {
        $data['message_thread_id'] = $topicId;
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);

    return $result;
}

function sendTelegramPhoto($filePath, $caption = '', $topicId = null) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendPhoto";
    $data = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'caption' => $caption,
        'parse_mode' => 'HTML'
    ];
    if ($topicId) {
        $data['message_thread_id'] = $topicId;
    }
    $data['photo'] = new CURLFile(realpath($filePath));

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);

    return $result;
}

function sendManagerTelegramMessage($message) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    $data = [
        'chat_id' => TELEGRAM_MANAGER_CHAT_ID, // Отдельный чат для менеджеров
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}

// Настройки приложения
define('BASE_URL', 'https://панель.памятьнародов.рф');
define('UPLOAD_DIR', 'uploads/');

function saveBackupTextFile($hash, $data) {
    $dir = UPLOAD_DIR . $hash . '/';
    if(!file_exists($dir)) mkdir($dir, 0777, true);
    
    $fileName = $dir . 'backup_' . date('Y-m-d_H-i-s') . '.txt';
    $content = "ФИО Героя: ".($data['namesave'] ?? '')."\n";
    $content .= "Кто заполняет: ".($data['name_poluchatel'] ?? '')."\n";
    $content .= "Телефон: ".($data['Phone'] ?? '')."\n";
    $content .= "Номер заказа: ".($data['order_id'] ?? '')."\n\n";
    
    $fields = [
        'childhood_memories','family_relations','childhood_qualities','bright_memories',
        'school_period','school_hobbies','school_values','school_dreams',
        'after_school','next_period','hobbies_changes','free_time',
        'family_relations_adult','character_qualities','goals_achievement',
        'front_reason','military_position','military_character','military_stories',
        'last_days','last_moments','awards','creativity'
    ];
    
    foreach($fields as $f){
        $content .= strtoupper($f).":\n";
        $content .= ($data[$f] ?? '') . "\n\n";
    }
    
    file_put_contents($fileName, $content);
    return $fileName;
}

// Подключение к базе данных
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES utf8");
} catch(PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Функция для генерации хэша
function generateHash($length = 10) {
    return substr(md5(uniqid(mt_rand(), true)), 0, $length);
}
?>